<?php

namespace App\Http\Controllers;

use App\Models\action;
use App\Models\Ticket;
use Illuminate\Http\Request;

class ActionController extends Controller
{


    public function interventionTechnicien($id)
    {

        $ticket = Ticket::where('technician_id',$id)->where('etat','!=','ABANDONER')->get();

            return response()->json($ticket);

    }




    public function storeAction(Request $request)
{










//    $validatedData = $request->validate([
//        'tech_id' => 'required|string',
//        'etat' => 'required|string',
//        'description' => 'nullable|string',
//        'ticket_id' => 'nullable|string',
//        'titre' => 'nullable|string',
//    ]);
    $action=new Action();
    $action->titre = $request->titre;
    $action->etat = $request->etat;
    $action->description = $request->description;
    $action->technician_id = $request->id_tech;
    $action->ticket_id = $request->id_ticket;
    $action->save();

    $ticket = Ticket::find($request->id_ticket);
    $ticket->etat = $request->etat;
    $ticket->technician_id=$request->id_tech;
    $ticket->save();
}

    public function store(Request $request, $idticket, $idtechnician)
    {
        try {
            // Validation des données
            $validatedData = $request->validate([
                'titre' => 'required|string',
                'etat' => 'required|string',
                'description' => 'nullable|string',
            ]);

            // Mettre à jour l'état du ticket
            $ticket = Ticket::findOrFail($idticket);
            $ticket->etat = $validatedData['etat'];
            $ticket->save();

            // Création d'une nouvelle action liée au ticket
            $action = new Action([
                'titre' => $validatedData['titre'],
                'etat' => $validatedData['etat'],
                'description' => $validatedData['description'],
                'technician_id' => $idtechnician,
                'ticket_id' => $idticket,
            ]);
            $action->technician_id = $idtechnician;
            $action->ticket_id = $idticket;
            // Enregistrement de l'action
            $action->save();

            // Réponse JSON avec succès
        } catch (\Exception $e) {
            // Log de l'erreur
            \Log::error('Erreur lors de l\'enregistrement des données: ' . $e->getMessage());

            // Réponse JSON d'erreur
            return response()->json(['error' => 'Erreur lors de l\'enregistrement des données'], 500);


        }

        $ticket->etat = $validatedData['etat'];
        if ($ticket->etat == 'Abandonnee') {
            $ticket->technician_id = null;
        }

        $ticket->save();

        return response()->json($action, 201);

    }

    public function getActions($id)
    {
        $action = Action::where('ticket_id', $id)
            ->with(['technician', 'ticket.client'])
            ->get();

        return response()->json($action);
    }





}
