<?php

// ApplicationController.php (dans app/Http/Controllers)

namespace App\Http\Controllers;

use App\Models\Application;
use App\Models\Client;
use App\Models\Location;
use App\Models\Ticket;
use Cassandra\Exception\ValidationException;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class ApplicationController extends Controller
{

    public function addApplicationClient($id_client,$id_app)
    {
        $app=Application::find($id_app);
        $app->client_id=$id_client;
        $app->save();
    }






public function getApplicationNotClient()
{
    $app=Application::where('client_id',null)->get();
    return response()->json($app);
}



    public function updateApplication($id, Request $request)
    {
        $app = Application::find($id);

        if (!$app) {
            return response()->json(['message' => 'Application not found'], 404);
        }

        $validated = $request->validate([
            'titre' => 'string',
            'description' => 'string',
            'prix' => 'integer',

            'file1' => 'file|mimes:jpeg,png,jpg,webp|max:2048',
        ]);

        if ($request->hasFile('file1')) {
            $imagePath = $request->file('file1')->store('images', 'public');
            $app->image = $imagePath ?? null;
        }

        $app->titre = $validated['titre'];
        $app->description = $validated['description'];
        $app->prix = $validated['prix'];

        $app->save();

        return response()->json(['message' => 'Application updated successfully', 'application' => $app]);
    }









    public function ApplicationRemoveClient($id)
    {
        $app=Application::find($id);
        $app->client_id=null;
        $app->save();
        return response()->json(['mess','rah ta7d application dyal had client']);

    }




    public function ApplicationsDeClient($id_client)
    {
        $appClient=Application::where('client_id',$id_client)->get();
        return response()->json($appClient);
    }






public function clientwithLocal($id)
{
    $clienLocal=Location::where('client_id',$id)->get();
    return response()->json($clienLocal);

}





    public function applicationsClientWithout($id_client)
    {
        // Trouver le client par ID
        $clientETApplication = Client::with('application')->find($id_client);



        // Retourner les applications du client
        return response()->json($clientETApplication);
    }




    public function TicketIdApplication1($id)
    {

        $app = Application::find($id);

        if (!$app) {
            return response()->json(['message' => 'app not found'], 404);
        }
        return response()->json($app);
    }









    public function TicketIdApplication($id)
    {
        // Find the ticket by its ID
        $ticket = Ticket::find($id);

        // Check if the ticket exists
        if (!$ticket) {
            return response()->json(['message' => 'Ticket not found'], 404);
        }

        // Retrieve the associated application
        $application = $ticket->application;

        // Check if the application exists
        if (!$application) {
            return response()->json(['message' => 'Application not found'], 404);
        }

        // Return the application as a JSON response
        return response()->json($application);
    }



    public function application($id)
    {
        $app = Application::find($id);
        return response()->json($app);
    }

//    public function updateApplication(Request $request, $id)
//    {
//        $app = Application::find($id);
//        if ($app) {
//            $app->titre = $request->titre;
//            $app->description = $request->description;
//            $app->prix = $request->prix;
//            if ($request->hasFile('file1')) {
//                $file = $request->file('file1');
//                $path = $file->store('images');
//                $app->file1 = $path;
//            }
//            $app->save();
//            return response()->json(['message' => 'Application updated successfully']);
//        }
//        return response()->json(['message' => 'Application not found'], 404);
//    }

//    public function Application($id)
//    {
//        $app=Application::find($id);
//    return response()->json($app);
//
//    }

    public function store(Request $request)
    {
        // Définition des règles de validation
        $rules = [
            'titre' => 'required|string|max:255',
            'description' => 'required|string',
            'prix' => 'required|numeric',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp',
        ];

        // Validation des données
        try {
            $validatedData = $request->validate($rules);
        } catch (ValidationException $e) {
            return response()->json([
                'message' => 'Validation failed',
                'errors' => $e->errors()
            ], 422);
        }

        // Création de l'application
        $application = new Application();
        $application->titre = $validatedData['titre'];
        $application->description = $validatedData['description'];
        $application->prix = $validatedData['prix'];

        // Gestion de l'image
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $path = $file->store('images', 'public');
            $application->image = $path;
        }
        $application->save();

        return response()->json([
            'message' => 'Application ajoutée avec succès!',
            'application' => $application
        ], 201); // 201 Created
    }





    public function ApplicationsClient($id)
    {
        // Fetch applications for the given client ID
        $applications = Application::where('client_id', $id)->get();

        // Check if any applications were found
        if ($applications->isEmpty()) {
            return response()->json([
                'message' => 'No applications found for the given client ID.',
                'data' => []
            ], 404);
        }

        // Return the applications in a structured response
        return response()->json([
            'message' => 'Applications retrieved successfully.',
            'data' => $applications
        ], 200);
    }





    public function tousApplications()
    {
        $applications = Application::all();

        return response()->json($applications);
    }


    public function delete($id)
    {
        $application = Application::find($id);

        if (!$application) {
            return response()->json('Application non trouvée', 404);
        }

        $application->delete();

        return response()->json('Application supprimée avec succès');
    }

    public function ListeApplicationTisYear(){
        $currentYear = Carbon::now()->year; // Get the current year
        $applications = Application::whereYear('created_at', $currentYear)->get();

        return response()->json($applications);
    }




//        $applications = new Application();
//        $applications->titre=$request->titre;
//        $applications->description=$request->description;
//        $applications->prix=$request->prix;
//
//        $applications->image=$request->image;
//
//         $applications->save();
//        return response()->json('mess','nadiii kaina');

      public  function  ListeApplication()
      {
          $application=Application::where('client_id',null)->get();
          return response()->json($application);
      }



public function applicationClient($id)
{
    $application=Application::where('client_id',$id)->get();
    return response()->json($application);

}
    public function applicationsAdmin()
    {
        $application=Application::all();
        return response()->json($application);

    }

}
