<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Audio;

class AudioController extends Controller
{

    public function store(Request $request)
    {
        $request->validate([
            'audio' => 'required|mimes:wav,mp3,ogg', // 20MB Max
        ]);

        if ($request->hasFile('audio')) {
            $audio = $request->file('audio');
            $path = $audio->store('audio_files', 'public'); // Store in 'storage/app/public/audio_files'

            $audio = new Audio();
            $audio->file_path = $path;
            $audio->save();

            return response()->json($audio);
        }

        return response()->json(['message' => 'Aucun fichier téléchargé'], 400);
    }
}
