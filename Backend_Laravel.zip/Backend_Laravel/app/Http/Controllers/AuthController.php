<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Admin;
use App\Models\Client;
use App\Models\Technician;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->only('login', 'password');

        // Log the credentials
        \Log::info('Credentials:', ['credentials' => $credentials]);

        if ($credentials['login'] === 'admin' && $credentials['password'] === 'admin') {
            $user = Admin::where('login', 'admin')->first();
            return response()->json(['user' => $user, 'role' => 'admin', 'id' => $user->id], 200);
        } else {
            // Check in Client and Technician tables
            $user = Client::where('login', $credentials['login'])->first()
                ?? Technician::where('login', $credentials['login'])->first();

            if ($user && Hash::check($credentials['password'], $user->password)) {
                $role = $user instanceof Client ? 'client' : 'technicien';
                return response()->json(['access_token' => 'dummy_token', 'user' => $user, 'role' => $role, 'id' => $user->id], 200);
            }
        }

        \Log::warning('Authentication failed for user:', ['login' => $credentials['login']]);

        return response()->json(['error' => 'Unauthorized'], 401);
    }


}
