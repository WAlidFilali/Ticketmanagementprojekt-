<?php
namespace App\Http\Controllers;

use App\Models\Application;
use App\Models\Client;
use App\Models\Location;
use App\Models\Technician;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class ClientController extends Controller
{


    public function getEmailNom($id)
    {
        $client=Client::find($id);
        return response()->json(['email'=> $client->email,'nom'=>$client->nom]);

    }

    public function deleteUser($role,$id)
    {

        try {
            if ($role === 'client') {
                $deleted = Client::where('id', $id)->delete();
                $res = $deleted ? 'client' : 'Client non trouvé';
            } else if ($role === 'technicien') {
                $deleted = Technician::where('id', $id)->delete();
                $res = $deleted ? 'technicien ' : 'Technicien non trouvé';
            }

            return response()->json(['message' => $res]);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Erreur lors de la suppression : ' . $e->getMessage()], 500);
        }
    }






    public function addClient($id,Request $request)
    {
        $client=Client::find($id);
        $client->nom=$request->nom;
        $client->prenom=$request->prenom;
        $client->email=$request->email;

        $client->telephone=$request->telephone;
        $client->login=$request->login;
if($request->password){
    $client->password = password_hash($request->password, PASSWORD_DEFAULT);
}


        $client->save();
    }







    public function getUser($id,$role)
    {
        if($role=='client'){
            $user=Client::find($id);
        }else
            $user=Technician::find($id);



        return response()->json($user);
    }





    public function storeUser(Request $request)
    {
        // Décoder les locations JSON en tableau associatif PHP
        if ($request->has('locations')) {
            $request->merge(['locations' => json_decode($request->locations, true)]);
        }

        // Validation simplifiée pour assurer la sécurité des données
        $validatedData = $request->all();

        // Logique de traitement des données validées
        try {
            // Hashage du mot de passe avant l'enregistrement
            $validatedData['password'] = Hash::make($validatedData['password']);

            // Début de la transaction
            DB::beginTransaction();

            // Création de l'utilisateur en fonction du rôle
            $user = null;
            $message = '';

            if ($validatedData['role'] === 'client') {
                // Supprimer les clés non nécessaires pour la création du client
                unset($validatedData['status'], $validatedData['image'], $validatedData['application_id']);

                // Création d'un client avec les données validées
                $user = Client::create($validatedData);

                // Si des localisations sont fournies, les enregistrer
                if (!empty($request->locations)) {
                    foreach ($request->locations as $locationData) {
                        $location = new Location();
                        $location->nom = $locationData['nom'];
                        $location->ville = $locationData['ville'];
                        $location->adresse = $locationData['adresse'];
                        $location->client_id = $user->id;
                        $location->save();
                    }
                }

                // Associer l'application au client si une application_id est fournie
                $application_id = $request->input('application_id');
                $application = Application::findOrFail($application_id);

                // Modifier l'ID du client de l'application
                $application->client_id = $user->id;

                // Sauvegarder les modifications de l'application
                $application->save();


                $message = 'Client ';


            } elseif ($validatedData['role'] === 'technicien') {
                if ($request->hasFile('image')) {
                    $imagePath = $request->file('image')->store('images', 'public');

                }
                // Création d'un technicien avec les données validées

//                $user = Technician::create($validatedData);
                $user = new Technician();
                $user->nom = $validatedData['nom'];
                $user->prenom = $validatedData['prenom'];
                $user->email = $validatedData['email'];
                $user->telephone = $validatedData['telephone'];
                $user->image = $imagePath ?? null;
                $user->login = $validatedData['login'];
                $user->password = bcrypt($request->input('password'));

                $user->status = $validatedData['status'];
                $user->role = $validatedData['role'];
                $user->save();

                $message = 'Technicien ';
            }

            // Confirmation de la transaction en base de données
            DB::commit();

            // Réponse JSON en cas de succès
            return response()->json([
                'message' => $message,
                'user' => $user
            ], 201);

        } catch (\Exception $e) {
            // En cas d'erreur, annuler la transaction et logguer l'erreur
            DB::rollBack();
            Log::error("Error creating user: " . $e->getMessage(), ['exception' => $e]);

            // Réponse JSON en cas d'erreur serveur
            return response()->json(['message' => 'Une erreur est survenue lors de la création de l\'utilisateur'], 500);
        }
    }




    public function listClient()
    {
        $clients = Client::all();
        return response()->json($clients, 200);
    }

    public function getClient($id)
    {
        $user = Client::find($id);

        if (!$user) {
            return response()->json(['error' => 'Client not found'], 404);
        }

        return response()->json($user, 200);
    }


    public function updateUser(Request $request, $id)
    {
        $validatedData = $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:clients,email,' . $id . '|unique:technicians,email,' . $id,
            'telephone' => 'required|string|max:20',
            'login' => 'required|string|max:255|unique:clients,login,' . $id . '|unique:technicians,login,' . $id,
            'password' => 'nullable|string',
            'role' => 'required|string|in:client,technicien',
            'status' => 'required_if:role,technicien|string',
            'image' => 'required_if:role,technicien|file|mimes:jpeg,png,jpg|max:2048',

            'locations' => 'array',
            'locations.*.nom' => 'required|string|max:255',
            'locations.*.ville' => 'required|string|max:255',
            'locations.*.adresse' => 'required|string|max:255',
        ]);

        try {
            $user = Client::findOrFail($id);
            Location::where('client_id', $id)->delete();
            if (!empty($validatedData['password'])) {
                $validatedData['password'] = Hash::make($validatedData['password']);
            } else {
                unset($validatedData['password']);
            }

            $user->update($validatedData);

            if (!empty($validatedData['locations'])) {
                Location::where('client_id',$id)->delete();
                foreach ($validatedData['locations'] as $locationData) {
                    $location = new Location();
                    $location->client_id = $user->id;
                    $location->nom = $locationData['nom'];
                    $location->ville = $locationData['ville'];
                    $location->adresse = $locationData['adresse'];
                    $location->save();
                }
            }

            return response()->json([
                'message' => 'Client a été modifié',
                'user' => $user
            ], 200);
        } catch (\Exception $e) {
            Log::error("Error updating user: " . $e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }


    public function destroyUser($id)
    {
        $client = Client::find($id);
        if (!$client) {
            return response()->json(['error' => 'User not found'], 404);
        }

        $client->delete();

        return response()->json(['message' => 'User deleted successfully'], 200);
    }

}


