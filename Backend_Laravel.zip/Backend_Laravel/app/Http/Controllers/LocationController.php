<?php

namespace App\Http\Controllers;

use App\Models\Application;
use App\Models\Client;
use App\Models\Location;
use Illuminate\Http\Request;

class LocationController extends Controller
{
    public function AjouterNvLocationUpdater(Request $request)
    {
        $location=new Location();
        $location->client_id=$request->id;
        $location->nom=$request->nom;
        $location->ville=$request->ville;
        $location->adresse=$request->adresse;
        $location->save();

    }






    public function get($id)
    {
        $location = Location::find($id);
        return response()->json($location);
    }

    public function UpdateLocalClient(Request $request)
    {
        $location = Location::find($request->id);

        if ($location) {
            // Update location fields based on request data
            $location->nom = $request->nom;
            $location->ville = $request->ville;
            $location->adresse = $request->adresse;
            $location->client_id = $request->client_id;

            // Save the updated location
            $location->save();

            return response()->json(['message' => 'Location updated successfully']);
        } else {
            return response()->json(['error' => 'Location not found'], 404);
        }
    }










    public function localRemoveClient($id)
    {
        $local=location::find($id);
        $local->delete();

        return response()->json(['mess','had local, rah ta7yd db client']);

    }


    public function ListeLocations($id)
    {
        try {
            $client = Client::with('locations')->findOrFail($id);
            return response()->json($client, 200);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Client not found'], 404);
        }
    }



//    public function updateClientWithLocations(Request $request, $id)
//    {
//        $validatedData = $request->validate([
//            'nom' => 'required|string|max:255',
//            'prenom' => 'required|string|max:255',
//            'email' => 'required|string|email|max:255|unique:clients,email,' . $id,
//            'telephone' => 'required|string|max:20',
//            'login' => 'required|string|max:255|unique:clients,login,' . $id,
//            'password' => 'nullable|string',
//            'role' => 'required|string|in:client,technicien',
//            'locations' => 'required|array',
//            'locations.*.id' => 'nullable|integer|exists:locations,id',
//            'locations.*.nom' => 'required|string|max:255',
//            'locations.*.ville' => 'required|string|max:255',
//            'locations.*.adresse' => 'required|string|max:255'
//        ]);
//
//        try {
//            $client = Client::findOrFail($id);
//
//            if (!empty($validatedData['password'])) {
//                $validatedData['password'] = Hash::make($validatedData['password']);
//            } else {
//                unset($validatedData['password']);
//            }
//
//            $client->update($validatedData);
//
//            // Mettre à jour les locations
//            foreach ($validatedData['locations'] as $locationData) {
//                if (isset($locationData['id'])) {
//                    // Mise à jour de la location existante
//                    $location = Location::findOrFail($locationData['id']);
//                    $location->update($locationData);
//                } else {
//                    // Création d'une nouvelle location
//                    $locationData['client_id'] = $client->id;
//                    Location::create($locationData);
//                }
//            }
//
//            return response()->json([
//                'message' => 'Client et locations ont été modifiés',
//                'client' => $client->load('locations')
//            ], 200);
//        } catch (\Exception $e) {
//            Log::error("Error updating client and locations: " . $e->getMessage());
//            return response()->json(['error' => $e->getMessage()], 500);
//        }
//    }


    public function LocationsDeClient($id)
    {
        $locations = Location::where('client_id', $id)->get();
        return response()->json($locations);
    }


}
