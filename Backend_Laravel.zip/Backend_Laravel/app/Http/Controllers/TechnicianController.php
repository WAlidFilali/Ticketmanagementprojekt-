<?php

namespace App\Http\Controllers;

use App\Models\Technician;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class TechnicianController extends Controller
{
public function getImage($id)
{
    $imgtech=Technician::find($id);
    return response()->json($imgtech->image);
}




//    public function interventionTechnicien($id)
//    {
//
//    }
    public function TechnicienUpdate($id, Request $request)
    {
        // Recherche du technicien par son ID
        $technicien = Technician::find($id);

        $imagePaths = [];
        if ($request->hasFile('image')) {
            $imagePaths['image'] = $request->file('image')->store('images', 'public');
            $technicien->image = $imagePaths['image'] ;
        }

        // Mise à jour des informations du technicien
        $technicien->nom = $request->input('nom');
        $technicien->prenom = $request->input('prenom');
        $technicien->email = $request->input('email');
        $technicien->telephone = $request->input('telephone');

        $technicien->login = $request->input('login');
        if($request->password){
            $technicien->password = bcrypt($request->input('password'));
        }

        $technicien->status = $request->input('status');

        $technicien->save();

        return response()->json(['message' => 'Technicien mis à jour avec succès', 'technicien' => $technicien], 200);
    }







    public function getStatusTech($id)
    {
        $status =Technician::find($id);

        return $status->status;

    }


    public function updateTechnicien(Request $request, $id)
    {
        $validatedData = $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'telephone' => 'required|string|max:20',
            'login' => 'required|string|max:255',
            'password' => 'nullable|string|min:6',
            'role' => 'required|string|max:50',
            'status' => 'nullable|string|max:50',
            'image' => 'nullable|mimes:jpeg,png,jpg|max:2048'
        ]);

        try {
            $technicien = Technician::find($id);

            if (!empty($validatedData['password'])) {
                $validatedData['password'] = Hash::make($validatedData['password']);
            } else {
                unset($validatedData['password']);
            }

            if ($request->hasFile('image')) {
                $path = $request->file('image')->store('images', 'public');
                $validatedData['image_path'] = $path;
            }

            $technicien->update($validatedData);

            return response()->json([
                'message' => 'Technicien a été modifié ',
                'technicien' => $technicien
            ], 200);
        } catch (\Exception $e) {
            Log::error("Error updating technicien: " . $e->getMessage());
            return response()->json(['error' => 'Erreur lors de la mise à jour du technicien'], 500);
        }
    }
    public function getTechnicien($id)
    {
        $technicien = Technician::find($id);

        if (!$technicien) {
            return response()->json(['error' => 'Technicien not found'], 404);
        }

        return response()->json($technicien, 200);
    }

    public function destroyTechnicien($id)
    {
        $technicien = Technician::find($id);

        Ticket::where('technician_id', $id)->update(['technician_id' => null]);


        if (!$technicien) {
            return response()->json(['error' => 'Technicien not found'], 404);
        }

        try {
            $technicien->delete();
            return response()->json(['message' => 'Technicien deleted successfully'], 200);
        } catch (\Exception $e) {
            Log::error("Error deleting technicien: " . $e->getMessage());
            return response()->json(['error' => 'Failed to delete technicien'], 500);
        }
    }

    public function listeTechnicien()
    {
        $techniciens = Technician::all();
        return response()->json($techniciens);
    }

    public function getTechnicienactive()
    {
        $techniciens = Technician::where('status', 'actif')->get();
        return response()->json($techniciens);
    }




    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::guard('technician')->attempt($credentials)) {
            $user = Auth::guard('technician')->user();
            $token = $user->createToken('TechnicianApp')->accessToken;

            return response()->json(['token' => $token, 'role' => 'technician']);
        } else {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
    }





}
