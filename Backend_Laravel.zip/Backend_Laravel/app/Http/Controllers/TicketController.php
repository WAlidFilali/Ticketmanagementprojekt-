<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Action;
class TicketController extends Controller
{





    public function ticketById($id)
    {
        $ticket=Ticket::with('audio','client')->find($id);
        return response()->json($ticket);
    }




    public function ticketClient($id)
    {
        $ticketClient=Ticket::where('client_id',$id)->get();
        return response()->json($ticketClient);
    }





    public function ticketEtat($id)
    {
        $ticket=Ticket::find($id);
         return response()->json($ticket->etat);
    }


    public function ListeMesTikcet($id)
    {
        $Ticket=Ticket::where('client_id',$id)->get();
        return response()->json($Ticket);
    }


    public function IntervanctionTechniciein($id)
    {
        $Ticket=Ticket::where('technician_id',$id)->get();
        return response()->json($Ticket);
    }







    public function store(Request $request)
    {
        // Validation des données reçues
        $validatedData = $request->validate([
            'description' => 'required|string',
            'application_id' => 'required|integer',
            'image1' => 'required|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',
            'image2' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',
            'image3' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',
            'audio_id' => 'nullable|integer|exists:audios,id', // Vérifie si l'audio_id existe dans la table 'audios'
            'client_id' => 'nullable|integer',
        ]);

        // Gestion des fichiers uploadés et création du chemin de stockage
        $imagePaths = [];
        if ($request->hasFile('image1')) {
            $imagePaths['image1'] = $request->file('image1')->store('images', 'public');
        }
        if ($request->hasFile('image2')) {
            $imagePaths['image2'] = $request->file('image2')->store('images', 'public');
        }
        if ($request->hasFile('image3')) {
            $imagePaths['image3'] = $request->file('image3')->store('images', 'public');
        }

        $ticket = new Ticket();
        $ticket->description = $validatedData['description'];
        $ticket->application_id = $validatedData['application_id'];
        $ticket->audio_id = $validatedData['audio_id'];
        $ticket->client_id = $validatedData['client_id']?? null;
        $ticket->image1 = $imagePaths['image1'] ?? null;
        $ticket->image2 = $imagePaths['image2'] ?? null;
        $ticket->image3 = $imagePaths['image3'] ?? null;
        $ticket->etat = 'ENVOYER';
        $ticket->save();

        // Retourne une réponse JSON indiquant le succès de l'opération
        return response()->json(['message' => 'Ticket ajouté avec succès !', 'ticket' => $ticket], 201);
    }


//    public function detail($id)
//    {
//        // Trouver le ticket par son ID avec la relation 'client' chargée
//        $infoTicket = Ticket::with('client')->find($id);
//
//        // Vérifier si le ticket existe
//        if (!$infoTicket) {
//            return response()->json(['error' => 'Ticket non trouvé'], 404);
//        }
//
//        // Mapper les détails du ticket et de son client associé
//        $tousinfo = [
//            'id' => $infoTicket->id,
//            'title' => $infoTicket->title,
//            'description' => $infoTicket->description,
//            'image1' => $infoTicket->image1,
//            'image2' => $infoTicket->image2,
//            'image3' => $infoTicket->image3,
//            'telephone' => $infoTicket->client ? $infoTicket->client->telephone : null,
//            'location_id' => $infoTicket->client ? $infoTicket->client->location_id : null,
//            'client_nom' => $infoTicket->client ? $infoTicket->client->nom : null,
//            'client_prenom' => $infoTicket->client ? $infoTicket->client->prenom : null,
//            'client_email' => $infoTicket->client ? $infoTicket->client->email : null,
//            'created_at' => $infoTicket->created_at,
//            'updated_at' => $infoTicket->updated_at,
//
//
//        ];
//
//        // Retourner les informations du ticket et du client associé sous forme de réponse JSON
//        return response()->json($tousinfo);
//    }

    public function envoye()
    {
        // Récupérer tous les tickets avec les informations du technicien
//        $tickets = Ticket::with('technician')->get();

        // Transformer les tickets pour inclure le nom du technicien
//        $ticketsWithTechnicianName = $tickets->map(function ($ticket) {
//            return [
//                'id' => $ticket->id,
//                'title' => $ticket->title,
//                'description' => $ticket->description,
//                'image1' => $ticket->image1,
//                'technician_id' => $ticket->technician_id,
//                'etat' => $ticket->etat,
//                'technicien_nom' => $ticket->technician ? $ticket->technician->nom : null,
//                'created_at' => $ticket->created_at,
//                'updated_at' => $ticket->updated_at,
//            ];
//        });

//        return response()->json($ticketsWithTechnicianName);

        $ticket=Ticket::where('etat', 'ENVOYER')
            ->orWhere('etat', 'ABANDONER')
            ->get();

        return response()->json($ticket);
    }

    public  function deleteTicket($id)
    {
//      $action= Action::where('ticket_id',$id);
//       $action->ticket_id=null;
//
//        $action->technicien_id=null;

        $ticket=Ticket::find($id);
        $ticket->delete();
        return response()->json(['mess'=>'Ticket a été  supprimer']);
    }

    public function affecteTechnicien(Request $request, $id)
    {
        $request->validate([
            'technician_id' => 'required|integer|exists:technicians,id',
            'descriptionAdmin' => 'nullable|string' // Rendre descriptionAdmin optionnel
        ]);

        $ticket = Ticket::findOrFail($id);
        $ticket->technician_id = $request->technician_id;
        if ($request->has('descriptionAdmin')) {
            $ticket->descriptionAdmin = $request->descriptionAdmin;
        }
        $ticket->save();

        return response()->json(['message' => 'Ticket a été affecté avec succès!']);
    }

//    public function ticketaffecte($id)
//    {
//
//        $tickets = Ticket::where ('technician_id',$id)->get();
//
//
//
//        return response()->json($tickets);
//    }



    public function ticketaffecte(Request $request)
    {
        $ticketId = $request->input('ticket_id');
        $technicianId = $request->input('technician_id');

        // Debug: Log the received IDs
        \Log::info("Received ticket_id: $ticketId, technician_id: $technicianId");

        $ticket = Ticket::find($ticketId);
        if ($ticket) {
            $ticket->technician_id = $technicianId;
            $ticket->save();

            // Debug: Log successful update
            \Log::info("Ticket updated successfully");

            return response()->json(['message' => 'Ticket affecté avec succès'], 200);
        } else {
            // Debug: Log ticket not found
            \Log::warning("Ticket not found with id: $ticketId");

            return response()->json(['message' => 'Ticket non trouvé'], 404);
        }
    }

    public function ticket()
    {

        $tickets = Ticket::where ('technician_id',null)->get();
        return response()->json($tickets);
    }




    public function detail($id)
    {
        $infoTicket = Ticket::with(['client', 'audio', 'actions.technician'])->find($id);

        if (!$infoTicket) {
            return response()->json(['error' => 'Ticket non trouvé'], 404);
        }

        $tousinfo = [
            'id' => $infoTicket->id,
            'local' => $infoTicket->local,
            'description' => $infoTicket->description,
            'descriptionAdmin' => $infoTicket->descriptionAdmin,
            'application' => $infoTicket->application,
            'image1' => $infoTicket->image1,
            'image2' => $infoTicket->image2,
            'image3' => $infoTicket->image3,
            'created_at' => $this->formatDateTime($infoTicket->created_at)['date'],
            'updated_at' => $infoTicket->updated_at,
            'client' => $infoTicket->client ? [
                'nom' => $infoTicket->client->nom,
                'prenom' => $infoTicket->client->prenom,
                'email' => $infoTicket->client->email,
                'telephone' => $infoTicket->client->telephone,
                'created_date' => $this->formatDateTime($infoTicket->client->created_at)['date'],
                'updated_date' => $this->formatDateTime($infoTicket->client->updated_at)['date'],
                'created_time' => $this->formatDateTime($infoTicket->client->created_at)['time'],
                'updated_time' => $this->formatDateTime($infoTicket->client->updated_at)['time'],
            ] : null,
            'audio' => $infoTicket->audio ? [
                'file_path' => $infoTicket->audio->file_path,
            ] : null,
            'actions' => $infoTicket->actions->map(function($action) {
                return [
                    'titre' => $action->titre,
                    'description' => $action->description,
                    'etat' => $action->etat,
                    'technician_id' => $action->technician_id,
                    'technician_nom' => $action->technician ? $action->technician->nom : null,
                    'technician_prenom' => $action->technician ? $action->technician->prenom : null,
                    'created_at' => $this->formatDateTime($action->created_at)['date'],
                    'updated_at' => $this->formatDateTime($action->updated_at)['date'],
                    'created_time' => $this->formatDateTime($action->created_at)['time'],
                    'updated_time' => $this->formatDateTime($action->updated_at)['time'],
                ];
            })
        ];

        return response()->json($tousinfo);
    }



    public function formatDateTime($datetime): array
    {
        $carbonDateTime = Carbon::parse($datetime);

        $formattedDateTime = [
            'date' => $carbonDateTime->isoFormat('YYYY-MM-DD'),
            'time' => $carbonDateTime->isoFormat('HH:mm:ss'),

        ];

        return $formattedDateTime;
    }



    public function prendre($id,$idtech)
    {
        $ticket = Ticket::find($id);
        if ($ticket) {
            $ticket->technician_id = $idtech;
            $ticket->save();
            return response()->json(['mess' => 'Ticket pris avec succès']);
        } else {
            return response()->json(['mess' => 'Ticket non trouvé'], 404);
        }
    }


   public function getIntervention()
    {
        $inter = Ticket::where('etat', '!=', 'ENVOYER')
            ->Where('etat', '!=', 'ABANDONER')
            ->get();
        return response()->json($inter);
    }



}
