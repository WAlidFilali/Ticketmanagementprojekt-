<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    protected $table = 'admins'; // or the name of your admin table
    protected $fillable = ['name', 'login', 'password','role'];

}
