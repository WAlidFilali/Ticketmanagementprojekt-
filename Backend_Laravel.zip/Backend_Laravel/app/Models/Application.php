<?php

// Application.php (dans app/Models)

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Application extends Model
{
    protected $table='Applications';
    protected $fillable = ['titre', 'description','image','prix','client_id'];

    public function client()
    {
        return $this->belongsTo(Client::class);
    }
//    public function ticket()
//    {
//        return $this->belongsTo(Ticket::class);
//    }
    public function ticket()
    {
        return $this->hasOne(Ticket::class);
    }
}
