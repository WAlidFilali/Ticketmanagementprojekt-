<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Audio extends Model
{
    use HasFactory;

    /**
     * @var false|mixed|string
     */
    protected  $table='audios';
    protected  $fillable = ['file_path'];

    public function ticket()
    {
        return $this->hasOne(Ticket::class, 'audio_id');
    }
//    protected $table = 'audios';
//
//    protected $fillable = ['file_path'];
//
//    public function ticket()
//    {
//        return $this->belongsTo(Ticket::class);
//    }
}
