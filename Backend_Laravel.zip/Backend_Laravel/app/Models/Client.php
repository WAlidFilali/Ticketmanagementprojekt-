<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    use HasFactory;
    public $timestamps = true;
    protected $fillable = [
        'nom',
        'prenom',
        'email',
        'telephone',
        'login',
        'password',
        'role',

    ];

    protected $hidden = [
        'password', 'remember_token',
    ];

    public function ticket()
    {
        return $this->hasMany(Ticket::class, 'client_id');
    }

    public function location()
    {
        return $this->hasMany(Location::class,'client_id');
    }

    public function application()
    {
        return $this->hasMany(Application::class,'client_id');
    }



}
