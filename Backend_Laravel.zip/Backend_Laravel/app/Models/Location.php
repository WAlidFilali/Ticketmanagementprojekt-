<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    use HasFactory;

    protected $fillable = ['nom', 'ville','adresse','client_id'];

    public function client()
    {
        return $this->belongsTo(Client::class);
    }
}
