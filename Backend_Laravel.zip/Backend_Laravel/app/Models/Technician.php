<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Technician extends Model
{
    use HasFactory;

    protected $fillable = [
        'nom', 'prenom', 'email', 'telephone', 'image', 'status', 'login', 'password', 'role'
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];

    public function compte()
    {
        return $this->hasOne(Compte::class, 'technician_id');
    }

    public function actions()
    {
        return $this->hasMany(Action::class);
    }


    public function ticket()
    {
        return $this->hasMany(Ticket::class, 'technician_id');
    }
}
