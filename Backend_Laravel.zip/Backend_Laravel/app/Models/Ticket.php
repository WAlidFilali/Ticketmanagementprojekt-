<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;

    protected $table = 'tickets';

    protected $fillable = [
         'description', 'image1', 'image2', 'image3', 'audio_id','technician_id','descriptionAdmin','etat','client_id','application_id'
    ];

//    public function client()
//    {
//        return $this->belongsTo(Client::class);
//    }
//
    public function audio()
    {
        return $this->belongsTo(Audio::class, 'audio_id');
    }
    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function application()
    {
        return $this->belongsTo(Application::class);
    }

    public function actions()
    {
        return $this->hasMany(Action::class);
    }

    public function technician()
    {
        return $this->belongsTo(Technician::class, 'technician_id');
    }
}
