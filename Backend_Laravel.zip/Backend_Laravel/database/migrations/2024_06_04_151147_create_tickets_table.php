<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();

            $table->string('description');
            $table->string('image1');

            $table->string('image2')->nullable();
            $table->string('image3')->nullable();
            $table->string('etat')->nullable();
//            $table->unsignedBigInteger('audio_id')->nullable();
//            $table->foreignId('client_id')->constrained()->cascadeOnDelete();
            // Add this line
            $table->string('descriptionAdmin')->nullable();
//            $table->unsignedBigInteger('client_id')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('tickets');
    }
};
