<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class articleseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('art')->insert([
            'local'=>'loc1',
            'Application'=>'application',
            'Description'=>'description',
            'image1'=>'im1','image2'=>'im2','image3'=>'im3',
        ]);
    }
}
