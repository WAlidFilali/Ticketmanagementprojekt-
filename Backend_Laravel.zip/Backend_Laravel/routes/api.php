<?php

use App\Http\Controllers\ActionController;
use App\Http\Controllers\Auth\ClientAuthController;
use App\Http\Controllers\Auth\TechnicianAuthController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\LocationController;
use App\Http\Controllers\LoginController;
use App\Models\Application;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TechnicianController;
use App\Http\Controllers\ApplicationController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\AudioController;


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

//------------user-------------------------//
Route::post('/user/add', [ClientController::class, 'storeUser']);

Route::get('/utilisateur/emailNom/{id}', [ClientController::class, 'getEmailNom']);

Route::delete('/utilisateurDelete/{role}/{id}', [ClientController::class, 'deleteUser']);

//------------Ticket--------------//



Route::get('/intervention', [TicketController::class, 'getIntervention']);


Route::get('/ticket/envoye/user/{id}', [TicketController::class, 'ticketClient']);

Route::post('/tickets/{id}', [TicketController::class, 'affecteTechnicien']);
Route::post('/ticket/add', [TicketController::class, 'store']);
Route::get('/ticket/envoye', [TicketController::class, 'envoye']);
Route::post('/upload-audio', [AudioController::class, 'store']);

Route::get('/technicien/{id}/image', [TechnicianController::class, 'getImage']);

Route::get('/intervention/technicien/{id}', [ActionController::class, 'interventionTechnicien']);

Route::get('/ticket/{id}', [TicketController::class, 'ticketById']);

Route::delete('/ticket/{id}', [TicketController::class, 'deleteTicket']);

Route::get('/ticket/detail/{id}', [TicketController::class, 'detail']);

Route::get('/ticket/{id}/etat', [TicketController::class, 'ticketEtat']);

Route::get('/MesTickets/{id}', [TicketController::class, 'ListeMesTikcet']);

Route::get('/ticket/prendre/{id}/{idtechnician}', [TicketController::class, 'prendre']);
///ticket/detail/
// User routes
Route::get('/client/{id}', [ClientController::class, 'getClient']);

Route::get('/client', [ClientController::class, 'listClient']);

Route::put('/user/update/{id}', [ClientController::class, 'updateUser']);

Route::delete('/user/delete/{id}', [ClientController::class, 'destroyUser']);

// Technician routes

Route::get('/technicien/{id}/status', [TechnicianController::class, 'getStatusTech']);

Route::get('/technicien/getTechnicienActive', [TechnicianController::class, 'getTechnicienactive']);

Route::get('/technicien',[TechnicianController::class,'listeTechnicien']);

Route::put('/list/technicien/{id}',[TechnicianController::class,'updateTechnicien']);

Route::get('/technicien/{id}',[TechnicianController::class,'getTechnicien']);

Route::delete('/delete/technicien/{id}',[TechnicianController::class,'destroyTechnicien']);

//--------------login-----  /envoye/user//



Route::post('/compte/check', [AuthController::class, 'login']);
Route::get('/ticketsaffecte/{id}', [TicketController::class, 'IntervanctionTechniciein']);

Route::post('/ticketaffecte', [TicketController::class, 'ticketaffecte']);
Route::get('/ticket', [TicketController::class, 'ticket']);

///ticket
//Route::post('client/login', [ClientAuthController::class, 'login']);
//
//Route::post('technicien/login', [TechnicianAuthController::class, 'login']);

//Route::post('/login', [LoginController::class, 'login']);


//-----action----//

Route::post('/action/{idticket}/{idtechnician}', [actionController::class, 'store']);


Route::post('/action', [actionController::class, 'storeAction']);

Route::post('/client/local', [locationController::class, 'AjouterNvLocationUpdater']);


Route::get('/action/ticketInter/{id}', [actionController::class, 'getActions']);


//Route::post('/applications/{id}', [ApplicationController::class, 'UpdateApplication']);


//---------application----------------------//

//Route::post('/client/location', [LocationController::class, 'UpdateLocalClient']);

Route::post('/client/location', [LocationController::class, 'UpdateLocalClient']);

Route::get('/ge/{id}', [LocationController::class, 'get']);


Route::get('/application/client/{id_client}', [ApplicationController::class, 'ApplicationsDeClient']);

Route::delete('/application/{id}/remove/client', [ApplicationController::class, 'ApplicationRemoveClient']);

Route::delete('/client/local/{id}', [locationController::class, 'localRemoveClient']);


Route::get('/application/client/{id}', [ApplicationController::class, 'ApplicationsClient']);

Route::get('/application/client/{id_client}/without', [ApplicationController::class, 'ApplicationsClientWithout']);

Route::get('/client/{id}/local', [ApplicationController::class, 'clientwithLocal']);

Route::get('/utilisateur/{id}/{role}', [ClientController::class, 'getUser']);


Route::get('/applicationNotClient', [ApplicationController::class, 'getApplicationNotClient']);


Route::get('/client/{id_client}/application/add/{id_app}', [ApplicationController::class, 'addApplicationClient']);

Route::post('/client/{id}', [ClientController::class, 'addClient']);

Route::post('/technicien/{id}', [TechnicianController::class, 'TechnicienUpdate']);

Route::get('/application/client/', [ApplicationController::class, 'tousAdmin']);
Route::post('/application', [ApplicationController::class, 'store']);

Route::get('/applications', [ApplicationController::class, 'tousApplications']);

Route::post('/applicationsUpdate/{id}', [ApplicationController::class, 'updateApplication']);

Route::get('/TicketApplication/{id}', [ApplicationController::class, 'TicketIdApplication']);

Route::get('/TicketApplication1/{id}', [ApplicationController::class, 'TicketIdApplication1']);

Route::get('/application', [ApplicationController::class, 'ListeApplication']);
Route::get('/application/thisYear', [ApplicationController::class, 'ListeApplicationTisYear']);

Route::delete('/application/{id}', [ApplicationController::class, 'delete']);
Route::get('/applicationClient/{id}', [ApplicationController::class, 'applicationClient']);

//--applicationsadmin()/

Route::get('/applicationsAdmin', [ApplicationController::class, 'applicationsAdmin']);




Route::get('/locations/{id}', [LocationController::class, 'ListeLocations']);





//Route::put('/clientEtLocation/update/{id}', [LocationController::class, 'updateClientWithLocations']);




Route::put('/clientEtLocation/update/{id}', [LocationController::class, 'updateClientWithLocations']);

Route::get('/clientLocation/{id}', [LocationController::class, 'LocationsDeClient']);







//Route::post('admin/login', 'AuthController@adminLogin');
//Route::post('admin/logout', 'AuthController@adminLogout');
//
//// Authentification pour les clients
//Route::post('client/login', 'AuthController@clientLogin');
//Route::post('client/logout', 'AuthController@clientLogout');
//
//// Authentification pour les techniciens
//Route::post('technicien/login', 'AuthController@technicienLogin');
//Route::post('technicien/logout', 'AuthController@technicienLogout');
