<h1>walid</h1>
<?php /**PATH C:\Users\walid\Desktop\Nouveau dossier (2)\projet_FE\resources\views/welcome.blade.php ENDPATH**/ ?>