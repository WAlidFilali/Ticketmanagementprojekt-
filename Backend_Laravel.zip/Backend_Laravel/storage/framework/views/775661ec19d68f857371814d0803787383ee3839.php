trdetrtrt
<?php /**PATH C:\Users\walid\Desktop\projet_FE\resources\views/welcome.blade.php ENDPATH**/ ?>