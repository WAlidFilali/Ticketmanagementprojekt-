import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateOrDefault'
})
export class DateOrDefaultPipe implements PipeTransform {
  transform(value: any, defaultValue: string): any {
    if (value === null || value === undefined) {
      return defaultValue;
    } else {
      const datePipe = new DatePipe('en-US');
      return datePipe.transform(value, 'short'); // Vous pouvez ajuster le format de date ici
    }
  }
}
