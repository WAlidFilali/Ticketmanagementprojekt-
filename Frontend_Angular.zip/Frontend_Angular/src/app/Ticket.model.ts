export interface Ticket {
  id: number;
  local: string;
  application: string;
  description: string;
  image1: string;
  image2: string;
  image3: string;
}
