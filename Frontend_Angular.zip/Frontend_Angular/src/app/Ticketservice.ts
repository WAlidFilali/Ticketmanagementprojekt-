// src/app/services/application.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ticket } from './Ticket.model';
@Injectable({
  providedIn: 'root'
})
export class Ticketservice {
  private apiUrl = 'http://localhost:8000/api/ticket/list';

  constructor(private http: HttpClient) {}

  getAllTicket(): Observable<Ticket[]> {
    return this.http.get<Ticket[]>(this.apiUrl);
  }

  getAllTicketUser(id:any){
    return this.http.get<Ticket[]>('http://localhost:8000/api/ticket/list/user/'+id);
  }


}
