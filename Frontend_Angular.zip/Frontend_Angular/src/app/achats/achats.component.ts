import {Component, OnInit} from '@angular/core';
import {TicketServiceService} from "../services/ticket-service.service";
import {ActivatedRoute} from "@angular/router";
import {DomSanitizer} from "@angular/platform-browser";
import {MatSnackBar} from "@angular/material/snack-bar";

@Component({
  selector: 'app-achats',
  templateUrl: './achats.component.html',
  styleUrl: './achats.component.css'
})
export class AchatsComponent implements OnInit{
  products: any[] = [];
  id: any;
  isLoading: boolean = false;
  totalDurationAnimation: number = 3;

  constructor(
    private ticketService: TicketServiceService,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {
    this.getProdClient();
  }

  getProdClient(): void {
    this.isLoading = true; // loading
    this.ticketService.getApplicationClient(this.ticketService.getIdUser()).subscribe((products) => {
      this.products = products;
    }, error => {
      console.error(error);
      this.snackBar.open('Erreur lors de la récupération des nouveaux produits', 'Fermer', {
        duration: 3000,
        panelClass: ['snackbar-error']
      });
      this.isLoading = false;
    });
    this.isLoading = false;

  }

  getAnimationDelay(index: number): string {
    const delay = (index * this.totalDurationAnimation) / this.products.length;
    return `${delay}s`;
  }

}
