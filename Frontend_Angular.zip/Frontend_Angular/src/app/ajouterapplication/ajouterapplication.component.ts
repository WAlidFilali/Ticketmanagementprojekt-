import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TicketServiceService } from '../services/ticket-service.service';

@Component({
  selector: 'app-ajouterapplication',
  templateUrl: './ajouterapplication.component.html',
  styleUrl: './ajouterapplication.component.css'
})
export class AjouterapplicationComponent implements OnInit {
  appForm!: FormGroup;
  isLoading: boolean = false;
  fileName: string = '';
  selectedFile?: File;

  constructor(
    private fb: FormBuilder,
    private service: TicketServiceService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.appForm = this.fb.group({
      titre: ['', Validators.required],
      description: ['', Validators.required],
      prix: ['', [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?$/)]]
    });
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile) {
      this.fileName = this.selectedFile.name;
    }
  }

  onSubmit(): void {
    if (this.appForm.valid) {
      const formData: FormData = new FormData();
      formData.append('titre', this.appForm.get('titre')?.value);
      formData.append('description', this.appForm.get('description')?.value);
      formData.append('prix', this.appForm.get('prix')?.value);
      if (this.selectedFile) {
        formData.append('image', this.selectedFile);
      }

      this.isLoading = true;
      this.service.addApplication(formData).subscribe(
        (res) => {
          this.handleSuccess('Application ajoutée avec succès!', res, () => {
            this.appForm.reset({
                  titre: '',
                  description: '',
                  prix: '',
              fileName:'',
                });

                Object.keys(this.appForm.controls).forEach(key => {
                  this.appForm.controls[key].setErrors(null);
                  this.appForm.controls[key].markAsPristine();
                  this.appForm.controls[key].markAsUntouched();
                });
            this.fileName = '';
            this.selectedFile = undefined;  // Réinitialiser selectedFile à undefined
          });
        },
        (error) => {
          this.handleError('tout les champs est obligatoire!', error);
        }
      );
    }
  }

  handleSuccess(message: string, data: any, callback?: () => void): void {
    this.isLoading = false;
    this.snackBar.open(message, 'Fermer', { duration: 3000, panelClass: ['snackbar-success'] });
    if (callback) callback();
  }

  handleError(message: string, error: any): void {
    this.isLoading = false;
    console.error(error);
    this.snackBar.open(message, 'Fermer', { duration: 3000, panelClass: ['snackbar-error'] });
  }
}
