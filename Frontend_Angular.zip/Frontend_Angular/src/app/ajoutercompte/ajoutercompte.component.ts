import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatSnackBar } from '@angular/material/snack-bar'; // Importer MatSnackBar
import { TicketServiceService } from '../services/ticket-service.service';

@Component({
  selector: 'app-ajoutercompte',
  templateUrl: './ajoutercompte.component.html',
  styleUrls: ['./ajoutercompte.component.css']
})
export class AjoutercompteComponent implements OnInit {
  hide = true;
  accountForm!: FormGroup;
  users: any;
  userRoles: { [key: number]: string } = {};  // Dictionnaire pour stocker les rôles des utilisateurs
  role!: string;
  isClientSelected: boolean = true;

  constructor(
    private fb: FormBuilder,
    private service: TicketServiceService,
    private snackBar: MatSnackBar
  ) {
    this.accountForm = this.fb.group({
      login: ['', Validators.required],
      password: ['', Validators.required],
      id_user: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.service.getAllUsersNoAccount().subscribe(
      res => {
        this.users = res;
        this.users.forEach((user: any) => {
          this.loadUserRole(user.id);
        });
      },
      err => {
        console.error(err);
      }
    );
  }

  loadUserRole(id: number): void {
    this.service.getUserRole(id).subscribe(
      res => {
        this.userRoles[id] = res.role;
      },
      err => {
        console.error(err);
      }
    );
  }

  onSubmit(): void {
    if (this.accountForm.valid) {
      const formData = new FormData();
      formData.append('login', this.accountForm.get('login')?.value);
      formData.append('password', this.accountForm.get('password')?.value);
      formData.append('id_user', this.accountForm.get('id_user')?.value);

      // Envoi des données au service pour la création du compte
      this.service.addCompte(formData).subscribe(response => {
        this.snackBar.open('Compte créé avec succès', 'Fermer', {
          duration: 3000
        });
        this.accountForm.reset({
          login: '',
          password: '',
          id_user: '',
        });

        Object.keys(this.accountForm.controls).forEach(key => {
          this.accountForm.controls[key].setErrors(null);
          this.accountForm.controls[key].markAsPristine();
          this.accountForm.controls[key].markAsUntouched();
        });
      }, error => {
        this.snackBar.open('Erreur lors de la création du compte', 'Fermer', {
          duration: 3000
        });
      });
    }
  }

  getRoleClass(id: number): string {
    return this.userRoles[id] === 'client' ? 'client-option' : 'technicien-option';
  }
}
