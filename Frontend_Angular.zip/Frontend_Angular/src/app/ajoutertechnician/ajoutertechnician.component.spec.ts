import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjoutertechnicianComponent } from './ajoutertechnician.component';

describe('AjoutertechnicianComponent', () => {
  let component: AjoutertechnicianComponent;
  let fixture: ComponentFixture<AjoutertechnicianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AjoutertechnicianComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AjoutertechnicianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
