import { Component } from '@angular/core';

@Component({
  selector: 'app-ajoutertechnician',
  templateUrl: './ajoutertechnician.component.html',
  styleUrl: './ajoutertechnician.component.css'
})
export class AjoutertechnicianComponent {

}
