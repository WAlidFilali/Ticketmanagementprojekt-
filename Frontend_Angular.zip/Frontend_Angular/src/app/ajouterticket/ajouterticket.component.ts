import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AchtasComponent } from '../audio/achtas.component';
import { AudioService } from '../audioservice';
import { TicketServiceService } from '../services/ticket-service.service';

@Component({
  selector: 'app-ajouterticket',
  templateUrl: './ajouterticket.component.html',
  styleUrls: ['./ajouterticket.component.css']
})
export class AjouterticketComponent implements OnInit {
  nomFichier1 = '';
  nomFichier2 = '';
  nomFichier3 = '';

  images: File[] = [];
  audioBlob: Blob | null = null;

  ticketForm: FormGroup;
  applications: any;

  audio_id: any;
  client_id: any;

  @ViewChild(AchtasComponent) audioRecorder: AchtasComponent | undefined;

  constructor(
    private fb: FormBuilder,
    private service: TicketServiceService,
    private snackBar: MatSnackBar,
    private audioService: AudioService
  ) {
    this.ticketForm = this.fb.group({
      application: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.client_id = this.service.getIdUser();
    console.log('Client ID in add ticket function: ' + this.client_id);

    if (this.client_id !== 0) {
      console.log('kan had id -->: ' + this.client_id);
      this.service.getApplicationClient(this.client_id).subscribe(
        res => {
          console.log("han jbr app dyal client hada .");
          this.applications = res;
        },
        err => {
          console.error('Error retrieving client applications:', err);
        }
      );
    } else {
      this.service.getAllApplications().subscribe(
        res => {
          console.log('All applications (admin): ' + res[0].id);
          this.applications = res;
        },
        err => {
          console.error('Error retrieving all applications:', err);
        }
      );
    }
  }

  onSubmit(): void {
    if (this.ticketForm.valid && this.atLeastOneImageSelected()) {
      const formData = new FormData();
      const applicationId = this.ticketForm.get('application')?.value;
      console.log('Application ID:', applicationId);
      const description = this.ticketForm.get('description')?.value;
      console.log('Description:', description);

      formData.append('application_id', applicationId);
      formData.append('description', description);
      if (this.client_id !== 0) {
        formData.append('client_id', this.client_id);
      }

      this.images.forEach((img, index) => {
        formData.append(`image${index + 1}`, img);
      });

      if (this.audioBlob) {
        const formDataAudio = new FormData();
        formDataAudio.append('audio', this.audioBlob, 'recording.wav');

        this.audioService.uploadAudio(formDataAudio).subscribe(
          response => {
            this.audio_id = response.id;
            console.log("Audio uploaded successfully! Audio ID: " + this.audio_id);

            formData.append('audio_id', this.audio_id);

            this.submitTicketForm(formData);
          },
          error => {
            console.error("Audio upload error: ", error);
            this.snackBar.open('Erreur lors de l\'upload de l\'audio.', 'Fermer', {
              duration: 3000,
              panelClass: ['snackbar-danger']
            });
          }
        );
      } else {
        this.submitTicketForm(formData);
      }
    } else {
      this.snackBar.open('Veuillez remplir tous les champs obligatoires et télécharger au moins une image.', 'Fermer', {
        duration: 3000,
        panelClass: ['snackbar-warning']
      });
    }
  }

  submitTicketForm(formData: FormData): void {
    console.log('Contenu de formData :');
    formData.forEach((value, key) => {
      console.log(`${key}: ${value}`);
    });

    this.service.addTicket(formData).subscribe(
      rep => {
        this.snackBar.open('Ticket envoyé avec succès!', 'Fermer', {
          duration: 3000,
          panelClass: ['snackbar-success']
        });
        this.resetForm();
      },
      error => {
        console.error("Erreur lors de l'envoi du ticket: ", error);
        this.snackBar.open('Erreur lors de l\'envoi du ticket!', 'Fermer', {
          duration: 3000,
          panelClass: ['snackbar-danger']
        });
      }
    );
  }

  onFileSelected(event: any, index: number): void {
    if (event.target.files.length > 0) {
      this.images[index] = event.target.files[0];
      switch (index) {
        case 0:
          this.nomFichier1 = this.images[index].name;
          break;
        case 1:
          this.nomFichier2 = this.images[index].name;
          break;
        case 2:
          this.nomFichier3 = this.images[index].name;
          break;
      }
    }
  }

  atLeastOneImageSelected(): boolean {
    return this.images.some(img => img !== undefined);
  }

  onAudioBlobReceived(blob: Blob) {
    this.audioBlob = blob;
  }
  onAudioBlobReceived1() {
    this.audioBlob = null;
  }



  resetForm(): void {
    // this.ticketForm.reset();
    // this.images = [];
    // this.nomFichier1 = '';
    // this.nomFichier2 = '';
    // this.nomFichier3 = '';

    setTimeout(() => {
      window.location.reload();
    }, 1500);
  }
}
