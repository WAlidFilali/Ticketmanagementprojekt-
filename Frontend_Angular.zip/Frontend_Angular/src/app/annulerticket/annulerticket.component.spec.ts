import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnulerticketComponent } from './annulerticket.component';

describe('AnnulerticketComponent', () => {
  let component: AnnulerticketComponent;
  let fixture: ComponentFixture<AnnulerticketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AnnulerticketComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AnnulerticketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
