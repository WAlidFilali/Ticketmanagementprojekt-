import { Component } from '@angular/core';

@Component({
  selector: 'app-annulerticket',
  templateUrl: './annulerticket.component.html',
  styleUrl: './annulerticket.component.css'
})
export class AnnulerticketComponent {

}
