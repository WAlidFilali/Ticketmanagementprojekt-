import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DemandeTicketComponent } from './demande-ticket/demande-ticket.component';
import { ListeTicketComponent } from './liste-ticket/liste-ticket.component';
import { NouveautesComponent } from './user/user-nav-top/nouveautes/nouveautes.component';
import { AchtasComponent } from './audio/achtas.component';
import { RenoverContratComponent } from './renover-contrat/renover-contrat.component';
import { ApplicationComponent } from './application/application.component';
import { SupprimerclientComponent } from './supprimerclient/supprimerclient.component';

import { ModifierclientComponent } from './modifierclient/modifierclient.component';


// import { AjoutercompteComponent } from './ajoutercompte/ajoutercompte.component';
import { ModifiertechnicianComponent } from './modifiertechnician/modifiertechnician.component';
import { SupprimiertechnicianComponent } from './supprimiertechnician/supprimiertechnician.component';
import { AjoutertechnicianComponent } from './ajoutertechnician/ajoutertechnician.component';

import { VoirlistetechnicianComponent } from './voirlistetechnician/voirlistetechnician.component';
import { VoirlescompteComponent } from './voirlescompte/voirlescompte.component';
import { ModifiercompteComponent } from './modifiercompte/modifiercompte.component';
import { SupprimercompteComponent } from './supprimercompte/supprimercompte.component';
import {MescontratComponent} from "./mescontrat/mescontrat.component";
import {AddUserComponent} from "./user/add-user/add-user.component";
import {ListUserComponent} from "./user/list-user/list-user.component";
import { UserTicketListComponent } from './user/user-ticket-list/user-ticket-list.component';
import { LoginComponent } from './login/login.component';
import { VisitorTemplateComponent } from './visitor-template/visitor-template.component';
import { ClientTemplateComponent } from './client-template/client-template.component';
import { AboutComponent } from './user/user-nav-top/about/about.component';
import { ContactComponent } from './user/user-nav-top/contact/contact.component';
import { AdminTemplateComponent } from './admin-template/admin-template.component';
import { AjouterapplicationComponent } from './ajouterapplication/ajouterapplication.component';
import { AjoutercompteComponent } from './ajoutercompte/ajoutercompte.component';
import { AjouterticketComponent } from './ajouterticket/ajouterticket.component';
import { TicketDetailsComponent } from './ticket-details/ticket-details.component';
import { VoirticketComponent } from './voirticket/voirticket.component';
import { ListeInterventionComponent } from './liste-intervention/liste-intervention.component';
import { TechnicienNavComponent } from './technicien-nav/technicien-nav.component';
import {AchatsComponent} from "./achats/achats.component";


const routes: Routes = [
  { path:'', redirectTo:'visit/login', pathMatch:'full'},
  { path:'visit', component: VisitorTemplateComponent, children:[
    { path: 'login', component: LoginComponent },
    { path: 'about', component: AboutComponent },
    { path: 'nouveautes', component: NouveautesComponent },
    { path: 'contact', component: ContactComponent },
  ]},


  { path:'client', component: ClientTemplateComponent, children:[
    { path: 'about', component: AboutComponent },
    { path: 'nouveautes', component: NouveautesComponent },
    { path: 'contact', component: ContactComponent },
    { path: 'ticket/list/user', component: ListeTicketComponent },
    { path: 'ticket/add', component: AjouterticketComponent },
    { path: 'achats', component: AchatsComponent },

  ]},

  { path:'technicien', component: TechnicienNavComponent, children:[
    { path: 'ticket/list', component: VoirticketComponent },
    { path: 'intervention/list', component: ListeInterventionComponent },

  ]},
  {
    path: 'admin',
    component: AdminTemplateComponent,
    children: [
      { path: 'user/add', component: AddUserComponent },
      { path: 'user/list', component: ListUserComponent },

      { path: 'application/list', component: ApplicationComponent },

      { path: 'application/add', component: AjouterapplicationComponent },
      // { path: 'account/add', component: AjoutercompteComponent},
      // { path: 'account/list', component: VoirlescompteComponent },

      { path: 'ticket/add', component: AjouterticketComponent },
      { path: 'ticket/list', component: VoirticketComponent},

      { path: 'intervention/list', component: ListeInterventionComponent},
    ],
  },

  { path: 'ticket/:id', component: TicketDetailsComponent },

  { path: 'application/list', component: ApplicationComponent },
  { path: 'application/add', component: AjouterapplicationComponent },

  { path: 'ticket/add', component: DemandeTicketComponent },

  { path: 'ticket/list', component: ListeTicketComponent },
  { path: 'ticket/list/user/:id', component: UserTicketListComponent },

  { path: 'liste-ticket', component: ListeTicketComponent },
  { path: 'achats', component: AchtasComponent  },
  { path: 'renover-contrat', component: RenoverContratComponent },

  { path: 'modifiertechnician', component: ModifiertechnicianComponent },
  { path: 'supprimertechnician', component: SupprimiertechnicianComponent },
  { path: 'ajoutertechnician', component: AjoutertechnicianComponent },
  { path: 'voirlistetechnician', component: VoirlistetechnicianComponent },

  { path: 'mesContrat', component: MescontratComponent },


  { path: 'modifiercompte', component: ModifiercompteComponent },
  { path: 'supprimercompte', component: SupprimercompteComponent },
  // { path: 'voirlistetechnician', component: VoirlistetechnicianComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
