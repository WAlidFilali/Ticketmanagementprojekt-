import { Component, OnInit } from '@angular/core';
import { TicketServiceService } from './services/ticket-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{
  title = 'ticket_FE';

  constructor(private service : TicketServiceService,
              private router : Router)
  {

  }

  ngOnInit(): void {
    // if(this.service.getIdUser() !=0){
    //   this.service.getUserRole(this.service.getIdUser()).subscribe(
    //     resRole=>{
    //       if(resRole.role === 'client'){
    //         this.router.navigateByUrl('/client/ticket/add')
    //       }
    //       else if(resRole.role === 'technicien'){
    //         this.router.navigateByUrl('/technicien')
    //       }
    //       else{
    //         this.router.navigateByUrl('/admin')
    //       }
    //     }
    //   )
    //   this.service.setIdUser(0)
    //   this.router.navigateByUrl('')
    // }
  }


}
