import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DemandeTicketComponent } from './demande-ticket/demande-ticket.component';
import { ListeTicketComponent } from './liste-ticket/liste-ticket.component';
import { NouveautesComponent } from './user/user-nav-top/nouveautes/nouveautes.component';

import { RenoverContratComponent } from './renover-contrat/renover-contrat.component';
import { ApplicationComponent } from './application/application.component';
import { SupprimerclientComponent } from './supprimerclient/supprimerclient.component';
import { ModifierclientComponent } from './modifierclient/modifierclient.component';
import { VoirlescompteComponent } from './voirlescompte/voirlescompte.component';
import { ModifiercompteComponent } from './modifiercompte/modifiercompte.component';
// import { AjoutercompteComponent } from './ajoutercompte/ajoutercompte.component';
import { AjouterticketComponent } from './ajouterticket/ajouterticket.component';
import { AnnulerticketComponent } from './annulerticket/annulerticket.component';
import { AffecterticketComponent } from './affecterticket/affecterticket.component';
import { VoirticketComponent } from './voirticket/voirticket.component';
import { VoirlisteapplicationComponent } from './voirlisteapplication/voirlisteapplication.component';
import { AjouterapplicationComponent } from './ajouterapplication/ajouterapplication.component';
import { SupprimierapplicationComponent } from './supprimierapplication/supprimierapplication.component';
import { ModifierapplicationComponent } from './modifierapplication/modifierapplication.component';
import { AjoutertechnicianComponent } from './ajoutertechnician/ajoutertechnician.component';
import { SupprimiertechnicianComponent } from './supprimiertechnician/supprimiertechnician.component';
import { ModifiertechnicianComponent } from './modifiertechnician/modifiertechnician.component';
import { VoirlistetechnicianComponent } from './voirlistetechnician/voirlistetechnician.component';
import { SupprimercompteComponent } from './supprimercompte/supprimercompte.component';
import {MatRadioButton, MatRadioGroup} from "@angular/material/radio";
import { ListetechnicianComponent } from './listetechnician/listetechnician.component';
import { AchtasComponent } from './audio/achtas.component';
import { MescontratComponent } from './mescontrat/mescontrat.component';
import {MatDialogModule} from "@angular/material/dialog";
import { EditeUtilisateurComponent } from './edite-utilisateur/edite-utilisateur.component';
import {AddUserComponent} from "./user/add-user/add-user.component";
import { UpdateUserComponent } from './user/update-user/update-user.component';
import {ListUserComponent} from "./user/list-user/list-user.component";
import { UserNavComponent } from './user/user-nav/user-nav.component';
import { UserNavTopComponent } from './user/user-nav-top/user-nav-top.component';
import { UserTicketListComponent } from './user/user-ticket-list/user-ticket-list.component';
import { LoginComponent } from './login/login.component';
import { ClientTemplateComponent } from './client-template/client-template.component';
import { VisitorTemplateComponent } from './visitor-template/visitor-template.component';
import { AboutComponent } from './user/user-nav-top/about/about.component';
import { ContactComponent } from './user/user-nav-top/contact/contact.component';
import { AdminTemplateComponent } from './admin-template/admin-template.component';
import { AdminNavComponent } from './admin-nav/admin-nav.component';
import { ErrorDialogComponent } from './error-dialog/error-dialog.component';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';
import { AjoutercompteComponent } from './ajoutercompte/ajoutercompte.component';
import { TicketDetailsComponent } from './ticket-details/ticket-details.component';
import { ListeInterventionComponent } from './liste-intervention/liste-intervention.component';
import { VoirHistoryInterventionActionComponent } from './voir-history-intervention-action/voir-history-intervention-action.component';
import { TechnicienNavComponent } from './technicien-nav/technicien-nav.component';
import { DatePipe } from '@angular/common';
import { AchatsComponent } from './achats/achats.component';
import {ChangeEtatTicketComponent} from "./change-etat-ticket/changeetatticket.component";
import { TtttComponent } from './tttt/tttt.component';

@NgModule({
  declarations: [
    AppComponent,
    DemandeTicketComponent,
    ListeTicketComponent,
    NouveautesComponent,
    AchtasComponent,
    RenoverContratComponent,
    ApplicationComponent,
    AddUserComponent,
    SupprimerclientComponent,
    ModifierclientComponent,
    ListUserComponent,
    AjoutercompteComponent,
    VoirlescompteComponent,

    ModifiercompteComponent,
    AjouterticketComponent,
    AnnulerticketComponent,
    AffecterticketComponent,
    VoirticketComponent,
    VoirlisteapplicationComponent,
    AjouterapplicationComponent,
    SupprimierapplicationComponent,
    ModifierapplicationComponent,
    AjoutertechnicianComponent,
    SupprimiertechnicianComponent,
    ModifiertechnicianComponent,
    VoirlistetechnicianComponent,
    SupprimercompteComponent,
    ListetechnicianComponent,
    AchtasComponent,
    MescontratComponent,
    EditeUtilisateurComponent,
    UpdateUserComponent,
    UserNavComponent,
    UserNavTopComponent,
    UserTicketListComponent,
    LoginComponent,
    VisitorTemplateComponent,
    ClientTemplateComponent,
    AboutComponent,
    ContactComponent,
    AdminTemplateComponent,
    AdminNavComponent,
    ErrorDialogComponent,
    ConfirmDialogComponent,
    TicketDetailsComponent,
    ListeInterventionComponent,
    VoirHistoryInterventionActionComponent,
    TechnicienNavComponent,
    AchatsComponent,
    ChangeEtatTicketComponent,
    TtttComponent,

  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatIconModule,
    MatButtonModule,
    MatExpansionModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    HttpClientModule,
    MatSnackBarModule,
    MatSelectModule,
    MatInputModule,
    MatFormFieldModule,
    MatProgressSpinnerModule,
    MatRadioGroup,
    MatRadioButton,
    FormsModule,
    MatDialogModule

  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
