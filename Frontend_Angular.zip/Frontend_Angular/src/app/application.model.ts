export interface Application {
  id: number;
  name: string;
  description: string;
  image: string;
}
