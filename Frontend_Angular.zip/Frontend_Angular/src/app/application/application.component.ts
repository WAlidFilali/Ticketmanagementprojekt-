import { Component, OnInit } from '@angular/core';
import { ErrorDialogComponent } from '../error-dialog/error-dialog.component';
import { Overlay } from '@angular/cdk/overlay';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TicketServiceService } from '../services/ticket-service.service';
import { DomSanitizer } from '@angular/platform-browser';
import { ModifierapplicationComponent } from '../modifierapplication/modifierapplication.component';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.css']
})
export class ApplicationComponent implements OnInit {
  products: any[] = [];
  id: any;
  isLoading: boolean = false;
  totalDurationAnimation: number = 3;

  constructor(
    private service: TicketServiceService,
    private dialog: MatDialog,
    private overlay: Overlay,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {
    this.getNvProd();
  }
  client_id: any;

  getNvProd(): void {
    this.isLoading = true; // loading
    this.service.getAllApplications().subscribe((products) => {
      this.isLoading = false;
      this.products = products;

      // Log the products in key-value format
      console.log("ttt: ", JSON.stringify(this.products, null, 2));

      this.products.forEach(product => {
        console.log("Product:");
        Object.entries(product).forEach(([key, value]) => {
          console.log(`  ${key}: ${value}`);
        });
      });
    }, error => {
      console.error(error);
      this.snackBar.open('Erreur lors de la récupération des nouveaux produits', 'Fermer', {
        duration: 3000,
        panelClass: ['snackbar-error']
      });
      this.isLoading = false;
    });
  }

  getStyles(client_id: any): any {
    let color: string;

    if (client_id == null || client_id == 0) {
      color = 'rgb(237, 179, 120)';
    } else {
      color = 'rgb(141, 47, 218)';
    }

    return { color };
  }


  openEditAppDialog(user_id: number): void {
    const dialog = this.dialog.open(ModifierapplicationComponent, {
      width: '500px',
      data: user_id,
      scrollStrategy: this.overlay.scrollStrategies.block(),
    });

    dialog.afterClosed().subscribe(res => {
      window.location.reload();
    });
  }

  deleteApp(id: number): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.service.deleteApplication(id).subscribe({
          next: () => {
            this.openErrorDialog('L\'application a été supprimée', 0);
            this.products = this.products.filter(prod => prod.id !== id);
          },
          error: (err: any) => {
            console.error(err);
            this.service.getUserApplication(id).subscribe(
              res => {
                console.log('id user : ' + res.id);
                this.openErrorDialog('<b>Action invalide : </b>Le Client : ' + res.nom + ' a cette application', res.id);
              },
              err => {
                console.log("error recupere compte: ", err);
              }
            );
          }
        });
      }
    });
  }

  openErrorDialog(message: string, additionalData: number): void {
    this.dialog.open(ErrorDialogComponent, {
      data: { message: message, additionalData: additionalData },
      width: '300px',
      disableClose: true
    });
  }
}
