import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AchtasComponent } from './achtas.component';

describe('AchtasComponent', () => {
  let component: AchtasComponent;
  let fixture: ComponentFixture<AchtasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AchtasComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AchtasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
