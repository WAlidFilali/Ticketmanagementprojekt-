import { Component, EventEmitter, Output } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import * as RecordRTC from 'recordrtc';

@Component({
  selector: 'app-achtas',
  templateUrl: './achtas.component.html',
  styleUrls: ['./achtas.component.css']
})
export class AchtasComponent {
  private record: RecordRTC.StereoAudioRecorder | undefined;
  protected recording = false;
  protected url: string | undefined;
  private error: string | undefined;

  @Output() audioBlobEvent = new EventEmitter<Blob>();

  minutes: number = 0;
  seconds: number = 0;
  private timer: any;

  constructor(private domSanitizer: DomSanitizer) {}

  sanitize(url: string) {
    return this.domSanitizer.bypassSecurityTrustUrl(url);
  }

  initiateRecording() {
    this.recording = true;
    this.startTimer();
    let mediaConstraints = {
      video: false,
      audio: true
    };
    navigator.mediaDevices
      .getUserMedia(mediaConstraints)
      .then(this.successCallback.bind(this), this.errorCallback.bind(this));
  }

  successCallback(stream: MediaStream) {
    var StereoAudioRecorder = RecordRTC.StereoAudioRecorder;
    this.record = new StereoAudioRecorder(stream, {
        mimeType: 'audio/wav',
        numberOfAudioChannels: 1
      });
    this.record.record();
  }

  stopRecording() {
    this.recording = false;
    clearInterval(this.timer);
    this.record?.stop(this.processRecording.bind(this));
  }

  processRecording(blob: Blob) {
    this.url = URL.createObjectURL(blob);
    this.audioBlobEvent.emit(blob);
  }

  deleteRecording() {
    this.url = undefined;
    this.recording = false;
    this.minutes = 0;
    this.seconds = 0;
  }

  errorCallback(error: string | undefined) {
    this.error = 'Cannot play audio in your browser';
  }

  startTimer() {
    this.timer = setInterval(() => {
      this.seconds++;
      if (this.seconds >= 60) {
        this.minutes++;
        this.seconds = 0;
      }
    }, 1000);
  }
}
