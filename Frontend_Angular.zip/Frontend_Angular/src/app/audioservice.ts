import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {FormGroup} from "@angular/forms";

@Injectable({
  providedIn: 'root'
})
export class AudioService {
  private baseUrl = 'http://localhost:8000/api';

  constructor(private http: HttpClient) { }

  // getAudios(): Observable<any> {
  //   return this.http.get(`${this.baseUrl}/audios`);
  // }

  uploadAudio(formData: FormData): Observable<any> {
    return this.http.post(`${this.baseUrl}/upload-audio`, formData);
  }
  //
  // getAudio(id: number): Observable<any> {
  //   return this.http.get(`${this.baseUrl}/audios/${id}`);
  // }
}
