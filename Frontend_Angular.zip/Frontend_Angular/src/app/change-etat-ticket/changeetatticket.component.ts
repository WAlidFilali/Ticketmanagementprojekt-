import { Component, Inject, OnInit } from '@angular/core';
import { TicketServiceService } from '../services/ticket-service.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-changeetatticket',
  templateUrl: './changeetatticket.component.html',
  styleUrls: ['./changeetatticket.component.css']
})
export class ChangeEtatTicketComponent implements OnInit {
  actionForm!: FormGroup;
  technicien: any;
  statuses: { [key: number]: string } = {};
  actions: any[] = [];
  action_ticket: any;
  id_tech_ticket: number = 0;
  id_user: number = -1;
  etat_ticket!: string;
  etatsTicket = ['ENCOURS', 'TERMINE', 'ABANDONER'];

  constructor(
    public dialogRef: MatDialogRef<ChangeEtatTicketComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private service: TicketServiceService,
    private snackBar: MatSnackBar
  ) {
    this.id_user = this.service.getIdUser();
    console.log('id*********>' + this.data);

    this.service.getTicketEtat(this.data).subscribe(
      (res) => {
        console.log('estat --->' + res);
        this.etat_ticket = res;
        this.actionForm.get('etat')?.setValue(this.etat_ticket);  // Set the value here after fetching it
      },
      (error) => {
        console.error('error etat : ' + error);
      }
    );

    this.actionForm = this.fb.group({
      titre: ['', Validators.required],
      description: ['', Validators.required],
      etat: ['', Validators.required],
      id_ticket: [this.data, Validators.required],
      id_tech: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    console.log('id user : ' + this.id_user);
    this.loadTechniciens();
    this.getIdTechId();
    this.getEtatTicket();
  }

  findNewestDate(actions: any[]) {
    if (actions.length === 0) {
      console.warn("No actions available to find the newest date.");
      return null;
    }

    this.action_ticket = actions.reduce((latest: { date: string | number | Date; }, current: { date: string | number | Date; }) => {
      return new Date(latest.date) > new Date(current.date) ? latest : current;
    });
    console.log(this.action_ticket);
    return this.action_ticket;
  }

  getEtatTicket() {
    this.service.getTicketEtat(this.data).subscribe(
      res => {
        console.log('gonna res!!!!');
        this.etat_ticket = res.etat;
        this.actionForm.get('etat')?.setValue(res.etat);
      },
      err => {
        console.log('error getting etat : ' + err);
      }
    );
  }

  getIdTechId() {
    if (this.id_user == 0) {
      console.log(this.id_user);
      console.log('wsalti bach takhud etat (id ticket) :' + this.data);
      this.service.getTicketEtat(this.data).subscribe(
        resEtat => {
          console.log('etat ticket li jat :' + resEtat.etat);
          this.service.getActionByTicket(this.data).subscribe(
            resActions => {
              this.actions = resActions.filter((action: { ticket: { etat: any; }; etatTicket: any; }) => {
                return action.ticket.etat === resEtat.etat && action.etatTicket === resEtat.etat;
              });
              this.actions.forEach((action: { id: number }) => {
                console.log('action :' + action.id);
              });

              const latestAction = this.findNewestDate(this.actions);

              if (latestAction) {
                this.id_tech_ticket = latestAction.technicien.id;
                console.log('Lhamdulh id tech : ' + this.id_tech_ticket);
                this.actionForm.get('id_tech')?.setValue(this.id_tech_ticket);
              }
            },
            err => {
              console.error(err);
            }
          );
        },
        err => {
          console.error(err);
        }
      );
    } else {
      console.log('set the id tech!! by : ' + this.id_user);
      this.actionForm.get('id_tech')?.setValue(this.id_user);
    }
  }

  loadTechniciens() {
    this.service.getAllTechniciens().subscribe(
      res => {
        this.technicien = res;
        this.technicien.forEach((tech: { id: number; }) => this.fetchStatus(tech.id));
      },
      err => {
        console.error(err);
      }
    );
  }

  fetchStatus(id: number) {
    this.service.getStatusTechnicien(id).subscribe(
      res => {
        this.statuses[id] = res;
      },
      err => {
        console.error(err);
      }
    );
  }

  getStatus(id: number): boolean {
    return this.statuses[id] === 'VALABLE';
  }

  selectionTicket(id_tech: number) {
    console.log('id ticket : ' + id_tech);
  }

  selectionTech(id_tech: number) {
    console.log('id tech : ' + id_tech);
  }

  onSubmit(): void {
    console.log('submit');
    if (this.actionForm.valid) {
      const formData = new FormData();
      formData.append('titre', this.actionForm.get('titre')?.value);
      formData.append('description', this.actionForm.get('description')?.value);
      formData.append('id_tech', this.actionForm.get('id_tech')?.value);
      formData.append('id_ticket', this.data);
      formData.append('etat', this.actionForm.get('etat')?.value);

      console.log('Form Data before submitting:', {
        titre: this.actionForm.get('titre')?.value,
        description: this.actionForm.get('description')?.value,
        id_tech: this.id_user == 0 ? this.actionForm.get('id_tech')?.value : String(this.id_user),
        id_ticket: this.data,
        etat: this.actionForm.get('etat')?.value,
      });

      this.service.addAction(formData).subscribe(
        (response) => {
          console.log('Action added successfully:', response);

          setTimeout(() => {
            window.location.reload();
          }, 1500);


          this.snackBar.open('Action Enregistré avec succès', 'Fermer', {
            duration: 3000
          });
          this.actionForm.reset({
            titre: '',
            description: '',
            etat: '',
            id_tech: '',
            id_ticket: this.data,
          });

          Object.keys(this.actionForm.controls).forEach(key => {
            this.actionForm.controls[key].setErrors(null);
            this.actionForm.controls[key].markAsPristine();
            this.actionForm.controls[key].markAsUntouched();
          });
        },


        (error) => {
          console.error(error);
          this.snackBar.open('Erreur lors d\'affectation !', 'Fermer', {
            duration: 3000
          });
        }
      );
    } else {
      console.log('Form is invalid:', this.actionForm.errors);
    }
  }
}
