import { Component } from '@angular/core';

@Component({
  selector: 'app-client-template',
  templateUrl: './client-template.component.html',
  styleUrl: './client-template.component.css'
})
export class ClientTemplateComponent {

}
