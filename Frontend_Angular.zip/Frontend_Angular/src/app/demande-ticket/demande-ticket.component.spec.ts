import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DemandeTicketComponent } from './demande-ticket.component';

describe('DemandeTicketComponent', () => {
  let component: DemandeTicketComponent;
  let fixture: ComponentFixture<DemandeTicketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DemandeTicketComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DemandeTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
