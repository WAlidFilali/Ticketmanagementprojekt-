import {Component, OnInit, ViewChild} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Serve } from '../serve';
import {AchtasComponent} from "../audio/achtas.component";
import {AudioService} from "../audioservice";


@Component({
  selector: 'app-demande-ticket',
  templateUrl: './demande-ticket.component.html',
  styleUrls: ['./demande-ticket.component.css']
})
export class DemandeTicketComponent implements OnInit {
  nomFichier1 = '';
  nomFichier2 = '';
  nomFichier3 = '';

  images: File[] = [];
  audioBlob: Blob | null = null;

  ticketForm: FormGroup;
  locals: string[] = ['Local 1', 'Local 2', 'Local 3'];
  applications: string[] = ['Application 1', 'Application 2', 'Application 3'];

  audio_id!: any;
  client_id!: any;


  @ViewChild(AchtasComponent) audioRecorder!: AchtasComponent;

  constructor(
    private fb: FormBuilder,
    private exampleService: Serve,
    private snackBar: MatSnackBar,
    private audioService : AudioService,
  ) {
    this.ticketForm = this.fb.group({
      local: ['', Validators.required],
      application: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit(): void {
  }

  onSubmit(): void {
    if (this.ticketForm.valid && this.atLeastOneImageSelected()) {
      const formData = new FormData();
      formData.append('local', this.ticketForm.get('local')?.value);
      formData.append('application', this.ticketForm.get('application')?.value);
      formData.append('description', this.ticketForm.get('description')?.value);
      this.client_id = 2
      formData.append('client_id', this.client_id);

      this.images.forEach((img, index) => {
        if (img) {
          formData.append(`image${index + 1}`, img);
        }
      });

      // Handle audio file upload if present
      if (this.audioBlob) {
        const formDataAudio = new FormData();
        formDataAudio.append('audio', this.audioBlob, 'recording.wav');

        this.audioService.uploadAudio(formDataAudio).subscribe(
          response => {
            this.audio_id = response.id;
            console.log("Audio uploaded successfully! Audio ID: " + this.audio_id);

            // Append audio_id to formData after audio is uploaded
            formData.append('audio_id', this.audio_id);

            // Submit the ticket form after ensuring audio_id is available
            this.submitTicketForm(formData);

          },
          error => {
            console.log("Audio upload error: " + error);
            this.snackBar.open('Erreur lors de l\'upload de l\'audio.', 'Fermer', {
              duration: 3000,
              panelClass: ['snackbar-danger']
            });
          }
        );
      } else {
        // If there's no audio file, submit the form directly
        this.submitTicketForm(formData);
      }
    } else {
      this.snackBar.open('Veuillez remplir tous les champs obligatoires et télécharger au moins une image.', 'Fermer', {
        duration: 3000,
        panelClass: ['snackbar-warning']
      });
    }
  }

// Separate method to submit the formData
  submitTicketForm(formData: FormData): void {
    this.exampleService.saveArt(formData).subscribe(
      rep => {
        this.snackBar.open('Ticket envoyé avec succès!', 'Fermer', {
          duration: 3000,
          panelClass: ['snackbar-success']
        });

      },
      error => {
        this.snackBar.open('Erreur!', 'Fermer', {
          duration: 3000,
          panelClass: ['snackbar-danger']
        });
      }
    );
  }

  onFileSelected(event: any, index: number): void {
    if (event.target.files.length > 0) {
      this.images[index] = event.target.files[0];
      if (index === 0) {
        this.nomFichier1 = this.images[index].name;
      } else if (index === 1) {
        this.nomFichier2 = this.images[index].name;
      } else if (index === 2) {
        this.nomFichier3 = this.images[index].name;
      }
    }
  }

  atLeastOneImageSelected(): boolean {
    return this.images.some(img => img !== null);
  }

  onAudioBlobReceived(blob: Blob) {
    this.audioBlob = blob;
  }
}
