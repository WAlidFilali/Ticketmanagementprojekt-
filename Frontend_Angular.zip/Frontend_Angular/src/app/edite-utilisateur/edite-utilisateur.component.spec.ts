import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditeUtilisateurComponent } from './edite-utilisateur.component';

describe('EditeUtilisateurComponent', () => {
  let component: EditeUtilisateurComponent;
  let fixture: ComponentFixture<EditeUtilisateurComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EditeUtilisateurComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EditeUtilisateurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
