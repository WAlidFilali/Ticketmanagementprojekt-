import { Component } from '@angular/core';

@Component({
  selector: 'app-edite-utilisateur',
  templateUrl: './edite-utilisateur.component.html',
  styleUrl: './edite-utilisateur.component.css'
})
export class EditeUtilisateurComponent {

}
