import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { TicketServiceService } from '../services/ticket-service.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { Overlay } from '@angular/cdk/overlay';

@Component({
  selector: 'app-error-dialog',
  templateUrl: './error-dialog.component.html',
  styleUrls: ['./error-dialog.component.css']
})
export class ErrorDialogComponent {
  showDeleteCompte: boolean = false;
  showDeleteApp: boolean = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { message: string, additionalData?: number, additionalData2?: number },
    private dialogRef: MatDialogRef<ErrorDialogComponent>,
    private service : TicketServiceService,
    private dialog: MatDialog,
    private overlay: Overlay,
    private snackBar : MatSnackBar,

  ) {
    console.log('id compte dialog: '+ this.data.additionalData);

    if(data.message.includes("<b>Action invalide : </b>Le client a un compte") || data.message.includes("<b>Action invalide : </b>Le technicien a un compte")){
      this.showDeleteCompte = true;
    }

    if(data.message.includes("<b>Action invalide : </b>Le client a un compte et des produits") && this.data.additionalData2 != 0){
      this.showDeleteApp = false
    }
  }

  handleDeleteCompte(): void {
    console.log('click DeleteCompte');
    const dialogRef = this.dialog.open(ConfirmDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (this.data.additionalData) {
          this.service.deleteCompte(this.data.additionalData).subscribe(
            res=>{
              console.log("delete!");
              this.snackBar.open('Compte bien Supprimer!', 'Fermer', {
              duration: 3000,
              });
            },
            err=>{
              console.log(err);
            }
          )
        }
      }
    });

    this.dialogRef.close();
  }

  handleDeleteApp(): void {
    console.log('click Delete Application');
    this.service.deleteApplication(this.data.additionalData2).subscribe(
      res=>{
        console.log("delete!");
        this.snackBar.open('Produit bien Supprimer!', 'Fermer', {
        duration: 3000,
        });
      },
      err=>{
        console.log(err);

      }
    )
    this.dialogRef.close();
  }
}
