import { Component, OnInit } from '@angular/core';
import {TicketServiceService } from '../services/ticket-service.service';
import { Overlay } from '@angular/cdk/overlay';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { ErrorDialogComponent } from '../error-dialog/error-dialog.component';
import { TicketDetailsComponent } from '../ticket-details/ticket-details.component';
import { VoirHistoryInterventionActionComponent } from '../voir-history-intervention-action/voir-history-intervention-action.component';
import { AffecterticketComponent } from '../affecterticket/affecterticket.component';
import {ChangeEtatTicketComponent} from "../change-etat-ticket/changeetatticket.component";

@Component({
  selector: 'app-liste-intervention',
  templateUrl: './liste-intervention.component.html',
  styleUrl: './liste-intervention.component.css'
})
export class ListeInterventionComponent implements OnInit{
  interventions: any[] = [];
  id_user: number = -1;
  isLoading: boolean = false;

  constructor(
    private service: TicketServiceService,
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private overlay: Overlay,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {
    this.id_user = this.service.getIdUser()
    this.getInterventions();
  }

  getSanitizedImage(image: any) {
    return this.sanitizer.bypassSecurityTrustUrl(`data:image/png;base64,${image}`);
  }

  getStyles(etat: string): any {
    let color: string;

    switch (etat) {
      case 'EFFECTUER':
        color =  'var(--bay-of-many)';
        break;
      case 'ENCOURS':
        color =  'rgb(237, 179, 120)';
        break;
      case 'TERMINE':
        color = 'rgb(120, 237, 141)';
        break;
      case 'ABANDONER':
        color = 'rgb(141, 47, 218)';
        break;
      default:
        color =  'var(--amaranth)';
    }

    return {
      'border-color': color,
      'box-shadow': `0 0 15px ${color}`
    };

  }


  getEtatClass(etat: string): string {
    switch (etat) {
      case 'ENVOYER':
        return 'etat-envoye';
      case 'EFFECTUER':
        return 'etat-effectue';
      case 'ENCOURS':
        return 'etat-en-cours';
      case 'TERMINE':
        return 'etat-termine';
      case 'ABANDONER':
        return 'etat-abandone';
      default:
        return '';
    }
  }

  getInterventions(): void {
    this.isLoading = true; // loading
    if(this.id_user == 0){
      this.service.getIntervention().subscribe(
        (intervention: any) => {
          console.log('it : '+ intervention.id)
        this.interventions = intervention;
        this.isLoading = false;
      },
      (error: any) => {
        console.error(error);
        this.snackBar.open('Erreur lors de la récupération des intervention', 'Fermer', {
          duration: 3000,
          panelClass: ['snackbar-error']
        });
        this.isLoading = false;
      });
    }else{
      this.service.getInterventionTechnicien(this.id_user).subscribe((intervention: any) => {
        this.interventions = intervention;
        this.isLoading = false;
      },
      (error: any) => {
        console.error(error);
        this.snackBar.open('Erreur lors de la récupération des intervention', 'Fermer', {
          duration: 3000,
          panelClass: ['snackbar-error']
        });
        this.isLoading = false;
      });
    }

  }

  openDetailInterventionDialog(intervention_id: number): void {
    const dialog = this.dialog.open(TicketDetailsComponent , {
      width: '450px',
      data: intervention_id,
      scrollStrategy: this.overlay.scrollStrategies.block(),
    });

    dialog.afterClosed().subscribe(res=>{
      window.location.reload();
    })
  }

  openHistoryInterventionDialog(id : number){
    const dialog = this.dialog.open(VoirHistoryInterventionActionComponent , {
      width: '600px',
      data: id,
      scrollStrategy: this.overlay.scrollStrategies.block(),
    });

    dialog.afterClosed().subscribe(res=>{
      window.location.reload();
    })
  }

  openAffecterInterventionDialog(id : number){
    const dialog = this.dialog.open(ChangeEtatTicketComponent , {
      data: id,
      scrollStrategy: this.overlay.scrollStrategies.block(),
    });

    dialog.afterClosed().subscribe(res=>{
      window.location.reload();
    })
  }

  annulerIntervention(id: number): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.service.removeTicket(id).subscribe({
          next: () => {
            this.openErrorDialog('Intervention a été annulé', 0);
            this.interventions = this.interventions.filter(intervention => intervention.id !== id);
          },
          error: (err: any) => {
            console.error(err);
          }
        });
      }
    });
  }

  openErrorDialog(message: string, additionalData: number): void {
    this.dialog.open(ErrorDialogComponent, {
      data: { message: message, additionalData: additionalData },
      width: '300px',
      disableClose: true
    });
  }
}

