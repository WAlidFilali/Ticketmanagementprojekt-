import {Component, OnInit} from '@angular/core';
import {Ticket} from "../Ticket.model";
import { TicketServiceService } from '../services/ticket-service.service';
import { Overlay } from '@angular/cdk/overlay';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DomSanitizer } from '@angular/platform-browser';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { ErrorDialogComponent } from '../error-dialog/error-dialog.component';
import { TicketDetailsComponent } from '../ticket-details/ticket-details.component';
import { ActivatedRoute } from '@angular/router';
//import { Ticketservice } from '../Ticketservice';


@Component({
  selector: 'app-liste-ticket',
  templateUrl: './liste-ticket.component.html',
  styleUrl: './liste-ticket.component.css'
})
export class ListeTicketComponent implements OnInit {
  tickets: any[] = [];
  id: any;
  isLoading: boolean = false;
  private client_id!: number;

  constructor(
    private service: TicketServiceService,
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private overlay: Overlay,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {

    this.client_id = this.service.getIdUser();
    console.log('Client ID in add ticket function: ' + this.client_id);
    this.getTickets();
  }

  getSanitizedImage(image: any) {
    return this.sanitizer.bypassSecurityTrustUrl(`data:image/png;base64,${image}`);
  }

  getEtatClass(etat: string): string {
    switch (etat) {
      case 'ENVOYER':
        return 'etat-envoye';
      case 'EFFECTUER':
        return 'etat-effectue';
      case 'EN COURS':
        return 'etat-en-cours';
      case 'TERMINE':
        return 'etat-termine';
      case 'ABANDONER':
        return 'etat-abandone';
      default:
        return '';
    }
  }

  getTickets(): void {
    this.isLoading = true; // loading
    console.log('ddddddddd')
    this.service.getTicketEnvoyeClient(this.service.getIdUser()).subscribe((tickets) => {
      this.tickets = tickets;
      this.isLoading = false;
    }, error => {
      console.error(error);
      this.snackBar.open('Erreur lors de la récupération des Tickets', 'Fermer', {
        duration: 3000,
        panelClass: ['snackbar-error']
      });
      this.isLoading = false;
    });
  }

  openDetailTicketDialog(ticket_id: number): void {
    const dialog = this.dialog.open(TicketDetailsComponent , {
      width: '450px',
      data: ticket_id,
      scrollStrategy: this.overlay.scrollStrategies.block(),
    });

    dialog.afterClosed().subscribe(res=>{
      window.location.reload();
    })
  }

  annulerTicket(id: number): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.service.removeTicket(id).subscribe({
          next: () => {
            this.openErrorDialog('Ticket a été annulé', 0);
            this.tickets = this.tickets.filter(ticket => ticket.id !== id);
          },
          error: (err: any) => {
            console.error(err);
          }
        });
      }
    });
  }

  openErrorDialog(message: string, additionalData: number): void {
    this.dialog.open(ErrorDialogComponent, {
      data: { message: message, additionalData: additionalData },
      width: '300px',
      disableClose: true
    });
  }
}
