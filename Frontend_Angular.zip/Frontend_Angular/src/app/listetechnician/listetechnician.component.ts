import { Component } from '@angular/core';

@Component({
  selector: 'app-listetechnician',
  templateUrl: './listetechnician.component.html',
  styleUrl: './listetechnician.component.css'
})
export class ListetechnicianComponent {

}
