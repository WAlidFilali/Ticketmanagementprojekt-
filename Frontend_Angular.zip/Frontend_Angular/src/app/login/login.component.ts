import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { TicketServiceService } from '../services/ticket-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  showOverlay = false;
  hide = false;
  loginForm!: FormGroup;
  usernameLabel = 'Entre le nom d\'utilisateur';
  passwordLabel = 'Enter Le mot de passe';

  constructor(private fb: FormBuilder,
              private service: TicketServiceService,
              private snackBar: MatSnackBar,
              private router: Router,
              private breakpointObserver: BreakpointObserver) {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
  }

  ngOnInit(): void {
    this.breakpointObserver.observe([Breakpoints.Small, Breakpoints.Handset])
      .subscribe(result => {
        if (result.matches) {
          this.usernameLabel = 'Username';
          this.passwordLabel = 'Password';
        } else {
          this.usernameLabel = 'Entre le nom d\'utilisateur';
          this.passwordLabel = 'Enter Le mot de passe';
        }
      });

    this.showOverlay = true;
    const overlayDiv = document.querySelector('.transparent-div');
    if (overlayDiv) {
      overlayDiv.classList.add('fade-in-login', 'opacity');
    }
  }

  save() {
    if (this.loginForm.invalid) {
      this.snackBar.open('Veuillez corriger les erreurs dans le formulaire.', 'Close', {
        duration: 3000,
        panelClass: ['snackbar-danger']
      });
      return;
    }

    const formData = {
      login: this.loginForm.get('username')?.value,
      password: this.loginForm.get('password')?.value
    };

    this.service.checkCompte(formData).subscribe(
      (res: any) => {
        if (res.error) {
          this.snackBar.open('Nom ou mot de passe est incorrect! Veuillez réessayer', 'Close', {
            duration: 3000,
            panelClass: ['snackbar-danger']
          });
        } else {

          const userRole = res.role;
          const idUser=res.id;
          console.log('id--->'+idUser)
          console.log("rolee--->"+userRole)
          this.service.setIdUser(idUser);
          switch (userRole) {
            case 'admin':
              this.router.navigateByUrl('/admin/ticket/list');
              console.log('admin id--->'+idUser)
              break;
            case 'client':
              this.router.navigateByUrl('/client/ticket/add');
              console.log('client id--->'+idUser)
              break;
            case 'technicien':
              this.router.navigateByUrl('/technicien/ticket/list');
              console.log('technicien id--->'+idUser)
              break;
            default:
              this.snackBar.open('Rôle inconnu! Veuillez contacter le support.', 'Close', {
                duration: 3000,
                panelClass: ['snackbar-danger']
              });
          }
        }
      },
      err => {
        this.snackBar.open('Nom ou mot de passe est incorrect! Veuillez réessayer', 'Close', {
          duration: 3000,
          panelClass: ['snackbar-danger']
        });
      }
    );
  }

  hideOverlay(): void {
    this.showOverlay = false;
  }

  onBackgroundClick(event: MouseEvent): void {
    this.hideOverlay();
  }

  onOverlayClick(event: MouseEvent): void {
    event.stopPropagation();
  }
}
