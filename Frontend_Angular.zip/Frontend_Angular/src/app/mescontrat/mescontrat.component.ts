import { Component } from '@angular/core';

@Component({
  selector: 'app-mescontrat',
  templateUrl: './mescontrat.component.html',
  styleUrl: './mescontrat.component.css'
})
export class MescontratComponent {

}
