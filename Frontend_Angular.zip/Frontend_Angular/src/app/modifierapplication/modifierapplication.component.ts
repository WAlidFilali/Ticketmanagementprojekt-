import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { TicketServiceService } from '../services/ticket-service.service';
import { DomSanitizer } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-modifierapplication',
  templateUrl: './modifierapplication.component.html',
  styleUrl: './modifierapplication.component.css'
})
export class ModifierapplicationComponent implements OnInit{
  app!: any;
  appForm!: FormGroup;
  isLoading: boolean = false;
  fileName: string = '';
  selectedFile!: File;

  constructor(
    public dialogRef: MatDialogRef<ModifierapplicationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private dialog: MatDialog,
    private service: TicketServiceService,

    private snackBar: MatSnackBar,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.isLoading = true;
    this.initForms();
    this.fetchAppData();

  }

  initForms(): void {

      this.appForm = this.fb.group({
        titre: ['', Validators.required],
        description: ['', Validators.required],
        prix: ['', [Validators.required]],
      });

  }

  fetchAppData(): void {
    console.log('this-->' +this.data);
    this.service.getApplicationById1(this.data).subscribe(
      (res: any) => {

        this.app = res;

        // this.app = this.transformProduct(this.app);
        this.isLoading = false;

        this.initializeForm();
      },
      error => this.handleError('Erreur lors de la récupération du produit!', error)
    );
  }


  imagePreview: any;
  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile) {
      this.fileName = this.selectedFile.name;

      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result;
      };
      reader.readAsDataURL(this.selectedFile);
    }
  }

  initializeForm(): void {
    this.appForm.patchValue({
      titre: this.app.titre,
      description: this.app.description,
      prix: this.app.prix,

    });

  }

  onSubmit(): void {
    if (this.appForm.valid) {
      const formData = new FormData();

      // Append form values from the local FormGroup
      formData.append('titre', this.appForm.value.titre);
      formData.append('description', this.appForm.value.description);
      formData.append('prix', this.appForm.value.prix);
      if (this.selectedFile) {
        formData.append('file1', this.selectedFile);
      }
      // @ts-ignore
      for (let [key, value] of formData) {
        console.log(`${key}: ${value}`);
      }
      console.log(this.data);
      this.service.updateApplication(this.data, formData).subscribe(


        res => {
          this.handleSuccess('Produit mis à jour avec succès', res);
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        },
        error => this.handleError('Erreur lors de la mise à jour du Produit', error)
      );
    }
  }

  onCancel(): void {
    this.dialogRef.close();
    window.location.reload();
  }

  handleSuccess(message: string, data: any, callback?: () => void): void {
    this.isLoading = false;
    this.snackBar.open(message, 'Fermer', { duration: 3000, panelClass: ['snackbar-success'] });
    if (callback) callback();
  }

  handleError(message: string, error: any): void {
    this.isLoading = false;
    console.error(error);
    this.snackBar.open(message, 'Fermer', { duration: 3000, panelClass: ['snackbar-error'] });
    this.isLoading = false;
  }

  getErrorMessage(formControlName: string): string {
    const control = this.appForm.get(formControlName);
    if (control?.hasError('required')) {
      return 'Ce champ est obligatoire';
    }
    if (control?.hasError('email')) {
      return 'Email invalide';
    }
    return '';
  }
}
