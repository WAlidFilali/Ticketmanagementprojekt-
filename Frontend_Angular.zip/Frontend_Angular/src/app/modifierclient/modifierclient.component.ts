import { Component } from '@angular/core';

@Component({
  selector: 'app-modifierclient',
  templateUrl: './modifierclient.component.html',
  styleUrl: './modifierclient.component.css'
})
export class ModifierclientComponent {

}
