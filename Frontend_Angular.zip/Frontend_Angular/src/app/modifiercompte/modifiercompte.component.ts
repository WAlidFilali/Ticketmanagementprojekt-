import { Component } from '@angular/core';

@Component({
  selector: 'app-modifiercompte',
  templateUrl: './modifiercompte.component.html',
  styleUrl: './modifiercompte.component.css'
})
export class ModifiercompteComponent {

}
