import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifiertechnicianComponent } from './modifiertechnician.component';

describe('ModifiertechnicianComponent', () => {
  let component: ModifiertechnicianComponent;
  let fixture: ComponentFixture<ModifiertechnicianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ModifiertechnicianComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ModifiertechnicianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
