import { Component } from '@angular/core';

@Component({
  selector: 'app-modifiertechnician',
  templateUrl: './modifiertechnician.component.html',
  styleUrl: './modifiertechnician.component.css'
})
export class ModifiertechnicianComponent {

}
