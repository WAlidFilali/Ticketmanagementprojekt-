import { Injectable } from '@angular/core';
import {BehaviorSubject, Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ProfilBtnService {

  private valueBtn = false;

  constructor() { }

  setValueBtn(data: boolean): void {
    this.valueBtn = data;
  }

  getValueBtn(): boolean {

    return this.valueBtn;
  }
}
