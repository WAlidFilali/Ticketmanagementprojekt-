import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RenoverContratComponent } from './renover-contrat.component';

describe('RenoverContratComponent', () => {
  let component: RenoverContratComponent;
  let fixture: ComponentFixture<RenoverContratComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RenoverContratComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RenoverContratComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
