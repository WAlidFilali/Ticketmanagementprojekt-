import { Component } from '@angular/core';

@Component({
  selector: 'app-renover-contrat',
  templateUrl: './renover-contrat.component.html',
  styleUrl: './renover-contrat.component.css'
})
export class RenoverContratComponent {

}
