import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Serve {
  private apiUrl = 'http://localhost:8000/api/ticket';

  constructor(private http: HttpClient) {}

  saveArt(formData: FormData): Observable<any> {
    return this.http.post(this.apiUrl+'/add', formData);
  }
}
