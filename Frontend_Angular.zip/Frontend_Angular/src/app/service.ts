import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';



@Injectable({
  providedIn: 'root'
})
export class Service {
  private apiUrl = 'http://localhost:8000/api/user';

  constructor(private http: HttpClient) { }

  addUser(user: any): Observable<any> {
    return this.http.post<any>(this.apiUrl+'/add', user).pipe(
      catchError(this.handleError)
    );
  }

  getClients(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:8000/api/listeclient1').pipe(
      catchError(this.handleError)
    );
  }

  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl+'/list/all').pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    console.error(error);
    return throwError('Something went wrong; please try again later.');
  }

  getUser(id: any) {
    return this.http.get(this.apiUrl+'/'+id).pipe(
      catchError(this.handleError)
    );
  }

  updateUser(id:any, user:any): Observable<any> {
    return this.http.put(this.apiUrl+'/update/'+id, user).pipe(
      catchError(this.handleError)
    );
  }

  deleteUser(id: number): Observable<any> {
    return this.http.delete(this.apiUrl+'/delete/'+id).pipe(
      catchError(this.handleError)
    );
  }

}
