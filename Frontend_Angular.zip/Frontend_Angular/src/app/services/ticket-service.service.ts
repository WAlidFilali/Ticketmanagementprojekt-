import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TicketServiceService {

  //---------login dyali---/
  private url = 'http://localhost:8000/api';

  loginn(login: string, password: string): Observable<any> {

    return this.http.post(`${this.url}/login`, { login, password });
  }







  // idUser: number = 0;

  // getIdUser(){
  //   return this.idUser;
  // }

  // setIdUser(id : number){
  //   this.idUser = id;
  // }

  private idUserKey = 'id';

  constructor(private http: HttpClient) {
    const storedIdUser = localStorage.getItem(this.idUserKey);
    this.idUser = storedIdUser ? parseInt(storedIdUser, 10) : 0;
    console.log("idd----------------------------->"+this.idUser)
  }

  private idUser: number = 0;

  getIdUser(): number {
    return this.idUser;
  }

  setIdUser(id: number): void {
    this.idUser = id;
    localStorage.setItem(this.idUserKey, id.toString());
    console.log("idd---------------------------///-->"+this.idUser)
  }

  //-----------Users-----------//
  private apiUrlUser = 'http://localhost:8000/api/utilisateur';

  getUser(id:any,role: string){
    return this.http.get<any>(this.apiUrlUser+'/'+id+'/'+role);
  }

  getUserRole(id:any){
    return this.http.get<any>(this.apiUrlUser+'/'+id+'/role');
  }

  getEmailNom(id:any){
    return this.http.get<any>(this.apiUrlUser+'/emailNom/'+id);
  }

  getUsersByRole(role:string){
    return this.http.get<any>(this.apiUrlUser+'/role/'+role);
  }

  getAllUsers(){
    return this.http.get<any>(this.apiUrlUser);
  }

  getAllUsersNoAccount(){
    return this.http.get<any>(this.apiUrlUser+'/no/compte');
  }

  updateUser(formData : any){
    return this.http.put<any>(this.apiUrlUser, formData);
  }

  deleteUser(id: any, role: string){
    console.log('hwa--'+role+'--hawa id--'+id)
    return this.http.delete<any>('http://localhost:8000/api/utilisateurDelete/'+role+'/'+id);
  }

  //-----------Client-----------//
  private apiUrlClient = 'http://localhost:8000/api/client';

  getClient(id:any){
    return this.http.get<any>(this.apiUrlClient+'/'+id);
  }

  getClientLocals(id:any){
    return this.http.get<any>(this.apiUrlClient+'/'+id+'/local');
  }

  getAllClients(){
    return this.http.get<any>(this.apiUrlClient);
  }

  addUser(formData : any){
    return this.http.post<any>('http://localhost:8000/api/user/add', formData);
  }

  addLocal(formData : any){
    return this.http.post<any>(this.apiUrlClient+'/local', formData);
  }

  private api = 'http://localhost:8000/api';



  updateLocal(formData: any) {
    return this.http.post<any>(`${this.api}/client/location`, formData);
  }

  deleteLocal(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrlClient}/local/${id}`);
  }

  removeLocal(id_local: number): Observable<any> {
    return this.http.put<any>(`${this.apiUrlClient}/local/remove`, id_local);
  }

  updateClient(id : any, formData : any){
    return this.http.post<any>(this.apiUrlClient+'/'+id, formData);
  }

  addAppToClient(id_client : number, id_app : number){
    return this.http.get<any>(this.apiUrlClient+'/'+id_client+'/application/add/'+ id_app);
  }

  deleteClient(id : any){
    return this.http.delete<any>(this.apiUrlClient+'/'+id);
  }

  //-----------Technicien-----------//
  private apiUrlTechnicien = 'http://localhost:8000/api/technicien';

  getImageTech(id:any){
    return this.http.get<any>(this.apiUrlTechnicien+'/'+id+'/image');
  }

  getTechnicien(id:any){
    return this.http.get<any>(this.apiUrlTechnicien+'/'+id);
  }


  getAllApplicationsNotclient(){
    return this.http.get<any>('http://localhost:8000/api/applicationNotClient');
  }
  getAllTechniciens(){
    return this.http.get<any>(this.apiUrlTechnicien);
  }

  addTechnicien(formData : any){
    return this.http.post<any>(this.apiUrlTechnicien, formData);
  }

  getStatusTechnicien(id: any): Observable<string> {
    return this.http.get<string>(`${this.apiUrlTechnicien}/${id}/status`, { responseType: 'text' as 'json' }).pipe(
      catchError(this.handleError)
    );
  }

  setStatusTechnicien(id_tech : number, status : string){
    return this.http.post<any>(this.apiUrlTechnicien+'/'+id_tech+'/status', status);
  }

  updateTechnicien(id : any,formData : any){
    return this.http.post<any>(this.apiUrlTechnicien+'/'+id, formData);
  }

  deleteTechnicien(id : any){
    return this.http.delete<any>(this.apiUrlClient+'/'+id);
  }



  //-----------Application----------//
  private apiUrlApp = 'http://localhost:8000/api/application';

  getAllApplications(): Observable<any> {
    return this.http.get<any>('http://localhost:8000/api/applications');
  }

  getAllApplicationsThisYear(): Observable<any> {
    return this.http.get<any>(this.apiUrlApp+'/thisYear');
  }

  getApplicationById(id: number): Observable<any> {
    return this.http.get<any>('http://localhost:8000/api/TicketApplication/'+id);
  }

  getApplicationById1(id: number): Observable<any> {
    return this.http.get<any>('http://localhost:8000/api/TicketApplication1/'+id);
  }

  getUserApplication(id:number): Observable<any> {
    return this.http.get<any>(`${this.apiUrlApp}/${id}/user`);
  }

  getApplicationClient(id:number): Observable<any> {
    return this.http.get<any>('http://localhost:8000/api/application/client/'+id);
  }

  getApplicationsClient(id_client: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrlApp}/client/${id_client}`);
  }

  // getAllApplicationsWithoutClient(id_client: number): Observable<any> {
  //   return this.http.get<any>(`${this.apiUrlApp}/client/${id_client}/without`);
  // }

  addApplication(application: any): Observable<any> {
    return this.http.post<any>('http://localhost:8000/api/application', application);
  }

  updateApplication(id:number, application: any): Observable<any> {
    return this.http.post<any>('http://localhost:8000/api/applicationsUpdate/'+id, application);
  }

  removeApplication(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrlApp}/${id}/remove/client`);
  }

  deleteApplication(id: any): Observable<void> {
    return this.http.delete<void>(`${this.apiUrlApp}/${id}`);
  }

  //-----------Compte-----------//
  private apiUrlCompte = 'http://localhost:8000/api/compte';


  checkCompte(formData:any){
    return this.http.post<any>(this.apiUrlCompte+'/check', formData);
  }

  getAllComptes(){
    return this.http.get<any>(this.apiUrlCompte);
  }

  getCompteUser(id_user : any){
    return this.http.get<any>(this.apiUrlCompte+'/user/'+id_user);
  }

  addCompte(formData : any){
    return this.http.post<any>(this.apiUrlCompte, formData);
  }

  deleteCompte(id : any){
    return this.http.delete<any>(this.apiUrlCompte+'/'+id);
  }

  //---------Ticket--------------//
  private apiUrlTicket = 'http://localhost:8000/api/ticket';

  getTicket(id:any){
    return this.http.get<any>(this.apiUrlTicket+'/'+id);
  }

  getTicketEnvoye(){
    return this.http.get<any>(this.apiUrlTicket+'/envoye');
  }

  getTicketEnvoyeClient(id :number){
    return this.http.get<any>(this.apiUrlTicket+'/envoye/user/'+id);
  }

  private apiUrlIntervention = 'http://localhost:8000/api/intervention';

  getIntervention(){
    return this.http.get<any>(this.apiUrlIntervention);
  }

  getInterventionClient(id :number){
    return this.http.get<any>(this.apiUrlTicket+'/intervention/client/'+id);
  }

  getInterventionTechnicien(id :number){
    return this.http.get<any>('http://localhost:8000/api/intervention/technicien/'+id);
  }

  getTicketEtat(id : number) {
    return this.http.get<any>(this.apiUrlTicket+'/'+id+'/etat');
  }

  addTicket(formData:any){
    return this.http.post<any>('http://localhost:8000/api/ticket/add', formData);
  }

  removeTicket(id:any){
    return this.http.delete<any>(this.apiUrlTicket+'/'+id);
  }

  //------------Action---------------//

  private apiUrlAction = 'http://localhost:8000/api/action';

  getAction(id:any){
    return this.http.get<any>(this.apiUrlAction+'/'+id);
  }

  getActionByTicket(id:any){
    return this.http.get<any>(this.apiUrlAction+'/ticket/'+id);
  }

  getActionsByIntervention(id:any){
    return this.http.get<any>(this.apiUrlAction+'/ticketInter/'+id);
  }

  getActionByTiketAndEtatAndTech(id_ticket:any, etat:string, id_tech : number){
    return this.http.get<any>(this.apiUrlAction+'/ticket/'+id_ticket+'/'+etat+'/tech/'+id_tech);
  }

  addAction(formData:any){
    return this.http.post<any>(this.apiUrlAction, formData);
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    if (error.error instanceof ErrorEvent) {

      console.error(error.error.message);
    } else {

      console.error();
    }

    return throwError('Something bad happened; please try again later.');
  }
}
