import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupprimerclientComponent } from './supprimerclient.component';

describe('SupprimerclientComponent', () => {
  let component: SupprimerclientComponent;
  let fixture: ComponentFixture<SupprimerclientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SupprimerclientComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SupprimerclientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
