import { Component } from '@angular/core';

@Component({
  selector: 'app-supprimerclient',
  templateUrl: './supprimerclient.component.html',
  styleUrl: './supprimerclient.component.css'
})
export class SupprimerclientComponent {

}
