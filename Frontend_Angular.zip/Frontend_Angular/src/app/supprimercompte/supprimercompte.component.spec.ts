import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupprimercompteComponent } from './supprimercompte.component';

describe('SupprimercompteComponent', () => {
  let component: SupprimercompteComponent;
  let fixture: ComponentFixture<SupprimercompteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SupprimercompteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SupprimercompteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
