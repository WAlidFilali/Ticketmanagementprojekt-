import { Component } from '@angular/core';

@Component({
  selector: 'app-supprimercompte',
  templateUrl: './supprimercompte.component.html',
  styleUrl: './supprimercompte.component.css'
})
export class SupprimercompteComponent {

}
