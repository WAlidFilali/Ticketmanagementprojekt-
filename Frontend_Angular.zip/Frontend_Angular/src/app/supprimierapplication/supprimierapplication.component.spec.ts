import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupprimierapplicationComponent } from './supprimierapplication.component';

describe('SupprimierapplicationComponent', () => {
  let component: SupprimierapplicationComponent;
  let fixture: ComponentFixture<SupprimierapplicationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SupprimierapplicationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SupprimierapplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
