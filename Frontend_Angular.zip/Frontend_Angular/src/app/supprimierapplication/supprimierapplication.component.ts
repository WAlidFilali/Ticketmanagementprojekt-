import { Component } from '@angular/core';

@Component({
  selector: 'app-supprimierapplication',
  templateUrl: './supprimierapplication.component.html',
  styleUrl: './supprimierapplication.component.css'
})
export class SupprimierapplicationComponent {

}
