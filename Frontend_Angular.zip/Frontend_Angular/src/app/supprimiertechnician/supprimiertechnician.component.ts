import { Component } from '@angular/core';

@Component({
  selector: 'app-supprimiertechnician',
  templateUrl: './supprimiertechnician.component.html',
  styleUrl: './supprimiertechnician.component.css'
})
export class SupprimiertechnicianComponent {

}
