import { Component, inject } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { TicketServiceService } from '../services/ticket-service.service';
import { Route, Router } from '@angular/router';
import {error} from "@angular/compiler-cli/src/transformers/util";

@Component({
  selector: 'app-technicien-nav',
  templateUrl: './technicien-nav.component.html',
  styleUrl: './technicien-nav.component.css'
})
export class TechnicienNavComponent {
  private breakpointObserver = inject(BreakpointObserver);
  image!:string

  constructor(private service : TicketServiceService,
              private route :Router
  ) {
  this.getImageTechnicien();
  }
  getImageTechnicien(){
    this.service.getImageTech(this.service.getIdUser()).subscribe(
      (res:any) =>{
        this.image=res;
      },
      (error:any)=>{
        console.log("no image"+error)
      }

    )

  }



  logOut(){
    this.service.setIdUser(0)
    this.route.navigateByUrl('')
  }

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
}
