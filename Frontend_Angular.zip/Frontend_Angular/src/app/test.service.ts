import { Injectable } from '@angular/core';
import * as http from "node:http";
import {HttpClient, HttpErrorResponse} from "@angular/common/http";
import {Observable, throwError} from "rxjs";
import {catchError} from "rxjs/operators";



@Injectable({
  providedIn: 'root'
})
export class TestService {

  constructor(private  http :HttpClient ) { }
  private url='http://localhost:8000/api/affiche';

  getafficher(): Observable<any>{
    return this.http.get(this.url).pipe(catchError(this.error));

  }
  private error(error :HttpErrorResponse){

    console.log('erro est :',this.error);
    return  throwError('return a');
  }

}
