import { Component, ElementRef, Inject, OnInit, Renderer2 } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { TicketServiceService } from '../services/ticket-service.service';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-ticket-details',
  templateUrl: './ticket-details.component.html',
  styleUrl: './ticket-details.component.css'
})
export class TicketDetailsComponent implements OnInit {
  isLoading: boolean = false;
  ticket: any;
  produit:any
  id!: number;

  constructor(
    public dialogRef: MatDialogRef<TicketDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private ticketService: TicketServiceService,
    private sanitizer: DomSanitizer,
    private datePipe: DatePipe,
    private el: ElementRef,
    private renderer: Renderer2,
  ) {}

  ngOnInit(): void {
    // this.id = this.route.snapshot.params['id'];
    this.isLoading = true;
    this.getTicketDetails(this.data);
  }

  formatDateOrDefault(date: any): string | null{
    return date ? this.datePipe.transform(date, 'short') : 'Pas encore terminer';
  }

  getProduit(id : number) {
    console.log('app id--->'+id)
    this.ticketService.getApplicationById(id).subscribe(
      (res : any)=>{
        this.produit = res
      },
      err=>{
        console.error();

      }
    )
  }

  getTicketDetails(id: number): void {
    this.ticketService.getTicket(id).subscribe(
      data => {
        this.ticket = data;
        this.getProduit(this.ticket.id);
        this.isLoading = false;
      },
      error => {
        console.error(error);
      }
    );
  }

  getSanitizedImage(image: any) {
    return this.sanitizer.bypassSecurityTrustUrl(`data:image/png;base64,${image}`);
  }

  getSanitizedAudio(audio: any) {
    return this.sanitizer.bypassSecurityTrustUrl(`data:audio/wav;base64,${audio}`);
  }

  onCancel(): void {
    this.dialogRef.close();
    window.location.reload();
  }


  printTicket() {
    const printContents = document.getElementById('printable-section')!.innerHTML;
    const originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
    location.reload();
  }
}
