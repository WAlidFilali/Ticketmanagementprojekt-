import { Component } from '@angular/core';

@Component({
  selector: 'app-tttt',
  templateUrl: './tttt.component.html',
  styleUrl: './tttt.component.css'
})
export class TtttComponent {

}
