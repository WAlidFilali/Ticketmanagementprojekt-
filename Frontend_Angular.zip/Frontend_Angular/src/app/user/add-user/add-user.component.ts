import { Component, OnInit } from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TicketServiceService } from '../../services/ticket-service.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  nomFichier = '';
  image!: File;

  userForm!: FormGroup;
  isClientSelected: boolean = true;
  isLoading: boolean = false;
   statusTech = [
    {value: 'CONGE', viewValue: 'Congé'},
    {value: 'MALADE', viewValue: 'Malade'},
    {value: 'OCCUPE', viewValue: 'Occupé'},
    {value: 'VALABLE', viewValue: 'Valable'},
  ];
  villes = [
    { value: 'Kénitra' },
    { value: 'Rabat' },
    { value: 'Casablanca' },
    { value: 'Salé' },
    { value: 'Fès' },
    { value: 'Tétouan' }
  ];

  appsWithoutUser: any;


  constructor(
    private fb: FormBuilder,
    private service: TicketServiceService,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {


    this.userForm = this.fb.group({
      nom: ['', [Validators.required, Validators.minLength(3), Validators.pattern('^[a-zA-Z]+$')]],
      prenom: ['', [Validators.required, Validators.minLength(3), Validators.pattern('^[a-zA-Z]+$')]],
      email: ['', [Validators.required, Validators.email]],
      telephone: ['', [Validators.required, Validators.pattern('^[0-9]{9,14}$')]],
      login: ['', [Validators.required, Validators.minLength(3), Validators.pattern('^[a-zA-Z]+$')]],
      password: ['', [Validators.required, Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]+$')]],
      role: ['client', [Validators.required]],
      status: [{ value: '', disabled: true }],
      image: [''],
      locations: this.fb.array([]),
      application: ['', Validators.required]
    });


    this.getAllApplicationNotUser();
  }

  onFileSelected(event: any): void {
    this.image = event.target.files[0];
    this.nomFichier = this.image.name;
    console.log('hani radi sf -->'+this.nomFichier)
  }

  get locations(): FormArray {
    return this.userForm.get('locations') as FormArray;
  }

  addLocation() {
    this.locations.push(this.createLocation());
  }

  removeLocation(index: number) {
    this.locations.removeAt(index);
  }

  createLocation(): FormGroup {
    return this.fb.group({
      nom: ['',Validators.required],
      ville: ['',Validators.required],
      adresse: ['',Validators.required]
    });
  }

  getAllApplicationNotUser() {
    this.isLoading = true;
    this.service.getAllApplicationsNotclient().subscribe(data => {

      this.appsWithoutUser = data;
      this.isLoading = false;
    });
  }

  onSubmit(): void {
    if (this.userForm.invalid) {
      this.snackBar.open('Veuillez remplir tous les champs obligatoires.', 'Fermer', {
        duration: 3000,
      });
      return;
    }
    const formValues = this.userForm.value; // Récupère les valeurs du formulaire
    const keyValuePairs = Object.entries(formValues); // Convertit en paires clé-valeur

    console.log('Form Values as Key-Value Pairs:');
    keyValuePairs.forEach(([key, value]) => {
      console.log(`${key}: ${value}`);
    });
    const formData = new FormData();
    formData.append('nom', this.userForm.get('nom')?.value);
    formData.append('prenom', this.userForm.get('prenom')?.value);
    formData.append('email', this.userForm.get('email')?.value);
    formData.append('telephone', this.userForm.get('telephone')?.value);
    formData.append('login', this.userForm.get('login')?.value);
    formData.append('password', this.userForm.get('password')?.value);
    formData.append('role', this.userForm.get('role')?.value);

    if (!this.isClientSelected) {
      formData.append('status', this.userForm.get('status')?.value);
      if (this.image) {
        formData.append('image', this.image);
        // console.log('hani radi sf -->'+this.image)

      }
    } else {
      const locations = this.userForm.get('locations')?.value || [];
      formData.append('locations', JSON.stringify(locations));
      const applicationId = this.userForm.get('application')?.value;
      formData.append('application_id', applicationId);
      console.log('is app--->'+applicationId);
    }

    this.service.addUser(formData).subscribe(
      (res) => {
        this.handleSuccess(res.message +' ajouté avec succès!', res, () => {
          this.resetForm();
          setTimeout(() => {
            // Code à exécuter après 1,5 seconde
            window.location.reload();
          }, 1500);
        });
      },
      (err) => {
        console.error('Error:', err);
        this.snackBar.open('Erreur lors de l\'ajout de l\'utilisateur : ' + err.error.message, 'Fermer', {
          duration: 3000,
        });
      }
    );
  }

  resetForm(): void {
    this.userForm.reset({
      nom: '',
      prenom: '',
      email: '',
      telephone: '',
      login: '',
      password: '',
      role: 'client'
    });
    this.nomFichier = '';
    this.image = undefined!;
    this.onSelectRole('client');
  }

  onSelectRole(role: string): void {
    this.isClientSelected = role === 'client';
    this.userForm.get('role')?.setValue(role); // Set the role in the form

    const statusControl = this.userForm.get('status');
    const imageControl = this.userForm.get('image');
    const locationsControl = this.userForm.get('locations');
    const applicationControl = this.userForm.get('application');

    if (this.isClientSelected) {
      statusControl?.disable();
      imageControl?.disable();
      locationsControl?.enable();
      applicationControl?.enable();
      this.addLocation();
    } else {
      statusControl?.enable();
      imageControl?.enable();
      locationsControl?.disable();
      applicationControl?.disable();
      this.userForm.setControl('locations', this.fb.array([])); // Clear locations for technicians
    }
  }

  handleSuccess(message: string, res: any, callback: () => void) {
    this.snackBar.open(message, 'Fermer', {
      duration: 3000,
    });
    callback();
  }
}
