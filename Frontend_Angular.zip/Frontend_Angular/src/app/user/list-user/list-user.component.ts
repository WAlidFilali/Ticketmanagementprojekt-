import { Component, OnInit } from '@angular/core';
import { Service } from '../../service';
import { MatDialog } from '@angular/material/dialog';
import { EditeUtilisateurComponent } from '../../edite-utilisateur/edite-utilisateur.component';
import {UpdateUserComponent} from "../update-user/update-user.component";
import {MatSnackBar} from "@angular/material/snack-bar";
import { TicketServiceService } from '../../services/ticket-service.service';
import { ErrorDialogComponent } from '../../error-dialog/error-dialog.component';
import { Overlay } from '@angular/cdk/overlay';
import { ConfirmDialogComponent } from '../../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {
  isLoading: boolean = true;
  users: any[] = [];
  roles = [
    {value: 'client', viewValue: 'Client'},
    {value: 'technicien', viewValue: 'Technicien'},
  ];
  role: string = 'client';
  user_id : any

  constructor(private service: TicketServiceService,
              private dialog: MatDialog,
              private overlay: Overlay,
              private snackBar : MatSnackBar) {}

  ngOnInit(): void {
    // this.loadUsers();
    this.filterUsersByRole(this.role);
  }

  loadUsers(): void {
    this.service.getAllUsers().subscribe((data: any[]) => {
      this.users = data;
      this.isLoading = false;
    });
  }

  filterUsersByRole(role: string): void {
    if (role == 'client') {
      this.isLoading = true;
      this.role = role;
      this.service.getAllClients().subscribe(
        (data: any[]) => {
          this.users = data;
          this.isLoading = false;
        },
        error => {
          console.error(error);
          this.isLoading = false;
        }
      );
    } else {
      this.service.getAllTechniciens().subscribe(
        (data: any[]) => {
          this.users = data;
          this.isLoading = false;
        },
        error => {
          console.error(error);
          this.isLoading = false;
        }
      );
    }
  }

  openEditUserDialog(user_id: number, role: any): void {
    const dialog = this.dialog.open(UpdateUserComponent, {
      width: '500px',
      data: { id: user_id, role: role },
      scrollStrategy: this.overlay.scrollStrategies.block(),
    });

    dialog.afterClosed().subscribe(res => {
      window.location.reload();
    });
  }

  //
  // deleteUser(id: number): void {
  //   this.user_id = id;
  //   console.log('id user : ' + this.user_id);
  //
  //   this.service.getUserRole(this.user_id).subscribe(
  //     resRole => {
  //       console.log("role : " + resRole.role);
  //       this.service.getCompteUser(this.user_id).subscribe(
  //         resCompte => {
  //           if (resCompte && resRole.role === 'client') {
  //             console.log('id compte client : ' + resCompte.id);
  //
  //             this.service.getApplicationClient(this.user_id).subscribe(
  //               resApp => {
  //                 if (resApp.length > 0) {
  //                   console.log('id compte client : '+resCompte.id);
  //                   console.log('id app client : '+resApp.id);
  //
  //                   this.openErrorDialog('<b>Action invalide : </b>Le ' + resRole.role + ' a un compte et des produits', resCompte.id, 0);
  //                 } else {
  //                   this.openErrorDialog('<b>Action invalide : </b>Le ' + resRole.role + ' a un compte', resCompte.id, 0);
  //                 }
  //               },
  //               errApp => {
  //                 console.log('Erreur lors de la récupération des applications du client : ', errApp);
  //               }
  //             );
  //
  //           } else {
  //             if(resRole.role === 'client'){
  //               console.log('you are client & NO compte 1');
  //
  //               this.service.getApplicationClient(this.user_id).subscribe(
  //                 resApp => {
  //                   if (resApp) {
  //                     this.openErrorDialog('<b>Action invalide : </b>Le ' + resRole.role + ' a des produit', 0, 0);
  //                   } else {
  //                     if(resRole.role === 'client'){
  //                       console.log('you are client & NO compte 1');
  //
  //                       this.service.getApplicationClient(this.user_id).subscribe(
  //                         resApp => {
  //                           if (resApp.length > 0) {
  //                             this.openErrorDialog('<b>Action invalide : </b>Le ' + resRole.role + ' a des produit', 0, 0);
  //
  //                           } else {
  //                             console.log('No Delete because Apps! 1');
  //                           }
  //                         },
  //                         errApp => {
  //                           console.log('Erreur lors de la récupération des applications du client : ', errApp);
  //                         }
  //                       );
  //
  //                     }
  //                   }
  //                 },
  //                 errApp => {
  //                   console.log('Erreur lors de la récupération des applications du client : ', errApp);
  //                 }
  //               );
  //
  //             }else{
  //
  //               this.openErrorDialog('<b>Action invalide : </b>Le ' + resRole.role + ' a un compte', resCompte.id, 0);
  //             }
  //           }
  //         },
  //         errCompte => {
  //           console.log("Erreur lors de la récupération du compte : ", errCompte);
  //           if(resRole.role === 'client'){
  //             console.log('you are client & NO compte 2');
  //
  //             this.service.getApplicationClient(this.user_id).subscribe(
  //               (resApp: any[] )=> {
  //                 if (resApp.length > 0) {
  //                   console.log('No Delete because Apps! 2');
  //                   this.openErrorDialog('<b>Action invalide : </b>Le ' + resRole.role + ' a des produit', 0, 0);
  //
  //                 } else {
  //
  //                   console.log('empty');
  //                   this.deleteUserConfirmed(id,resRole.role)
  //                   }
  //               },
  //               errApp => {
  //                 console.log('Erreur lors de la récupération des produits du client : ', errApp);
  //               }
  //             );
  //
  //           }else{
  //             this.deleteUserConfirmed(id,resRole.role)
  //           }
  //
  //
  //         }
  //       );
  //     },
  //     errRole => {
  //       console.log('Erreur lors de la récupération du rôle de l\'utilisateur : ' + errRole);
  //     }
  //   );
  // }

  deleteUserConfirmed(id: number, role: string): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: { id: id, role: role }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (id) {
          this.isLoading = true;
          console.log('Id i hanm7i: ' + id + ', Role: ' + this.role);
          this.service.deleteUser(id,this.role).subscribe({
            next: (res) => {
              console.log(   res +   'supprimé avec succès.');
              this.openErrorDialog('Le ' + res.message+ ' a été supprimé', 0, 0);
              this.users = this.users.filter(user => user.id !== id);
            },
            error: (err: any) => {
              console.error('Erreur lors de la suppression de l\'utilisateur:', err);
            },
            complete: () => {
              this.isLoading = false;
            }
          });
        }
      }
    });
  }



  openErrorDialog(message: string, additionalData: number, additionalData2: number): void {
    this.dialog.open(ErrorDialogComponent, {
      data: { message: message, additionalData: additionalData },
      width: '500px',
    });
  }
}
