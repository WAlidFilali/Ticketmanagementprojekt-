import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from "@angular/material/dialog";
import { FormArray, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";
import { TicketServiceService } from '../../services/ticket-service.service';
import { ConfirmDialogComponent } from '../../confirm-dialog/confirm-dialog.component';
import { DomSanitizer } from '@angular/platform-browser';
import { ChangeDetectorRef } from '@angular/core';
import {log} from "@angular-devkit/build-angular/src/builders/ssr-dev-server";
import {formatDate} from "@angular/common";

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {
  user!: any;
  userForm!: FormGroup;
  newLocalForm!: FormGroup;
  isLoading: boolean = false;
  products: any[] = [];
  apps!: any;
  role: any;
  appsWithoutUser: any;
  statusTechnicien!: string;

  villes = [
    { value: 'Kénitra' },
    { value: 'Rabat' },
    { value: 'Casablanca' },
    { value: 'Salé' },
    { value: 'Fès' },
    { value: 'Tétouan' }
  ];

  statusTech = [
    { value: 'CONGE', viewValue: 'Congé' },
    { value: 'MALADE', viewValue: 'Malade' },
    { value: 'OCCUPE', viewValue: 'Occupé' },
    { value: 'VALABLE', viewValue: 'Valable' },
  ];
  fileName!: string;

  constructor(
    public dialogRef: MatDialogRef<UpdateUserComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private dialog: MatDialog,
    private service: TicketServiceService,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.isLoading = true;
    this.getRole();
    this.getProd();
  }

  getRole(): void {
    if (this.data.role === 'client') {
      this.getAllApplicationNotUser();
    }
    if (this.data.role === 'technicien') {
      this.fetchStatusTechnicien();
    }
  }
  deleteImage(): void {
    this.userForm.patchValue({ image: null }); // Mettre à null ou une valeur par défaut
  }
  initForms(): void {
    if (this.data.role === 'client') {
      this.userForm = this.fb.group({
        nom: ['', Validators.required],
        prenom: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        telephone: ['', [Validators.required,Validators.pattern('^[0-9]+(\.[0-9]+)?$')]],
        login: ['', Validators.required],
        password: [''],
        locals: this.fb.array([]),
      });

      this.newLocalForm = this.fb.group({
        nom: ['', Validators.required],
        ville: ['', Validators.required],
        adresse: ['', Validators.required],
      });
    } else {
      this.userForm = this.fb.group({
        nom: ['', Validators.required],
        prenom: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        telephone: ['', Validators.required],
        login: ['', Validators.required],
        password: [''],
        image: [''],
        status: [this.statusTechnicien]
      });
    }
  }
  selectedFile?: File;
  imagePreview: any;
  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile) {
      this.fileName = this.selectedFile.name;

      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result;
      };
      reader.readAsDataURL(this.selectedFile);
    }
  }

  fetchUserData(): void {
    this.service.getUser(this.data.id, this.data.role).subscribe(
      (res: any) => {
        this.user = res;
        this.initializeForm();
        if (this.data.role === 'client') {
          this.fetchClientLocals();
        }
        this.isLoading = false;
      },
      error => this.handleError('Erreur lors de la récupération de l\'utilisateur', error)
    );
  }

  fetchClientLocals(): void {
    this.service.getClientLocals(this.data.id).subscribe(
      (locals: any) => {
        locals.forEach((local: any) => this.addLocal(local));
      },
      error => this.handleError('Erreur lors de la récupération des locaux', error)
    );
  }

  fetchStatusTechnicien(): void {
    this.service.getStatusTechnicien(this.data.id).subscribe(
      res => {
        this.statusTechnicien = res;
        this.initForms();
        this.fetchUserData();
      },
      err => this.handleError('Erreur lors de la récupération du statut du technicien', err)
    );
  }

  applyStatusToTechnicien(technicienStatus: string): void {
    this.service.setStatusTechnicien(this.data.id, technicienStatus).subscribe(
      res => {
        console.log('Status SET tech id : ' + res.id);
      },
      err => this.handleError('Erreur lors de la mise à jour du statut du technicien', err)
    );
  }

  selectAppUser(app: any): void {
    if (app) {

      console.log('hadiya id de appp--------->'+app)
      this.service.addAppToClient(this.data.id, app).subscribe(


        (data: any) => {
          this.handleSuccess('Produit ajouté avec succès', data, () => {
            this.products = data;
            this.isLoading = true;
            this.cd.detectChanges();
            this.isLoading = false;
            window.location.reload();
          });
        },
        error => this.handleError('Erreur lors de l\'ajout du produit au client', error)
      );
    }
  }

  initializeForm(): void {
    this.userForm.patchValue({
      nom: this.user.nom,
      prenom: this.user.prenom,
      email: this.user.email,
      telephone: this.user.telephone,
      image: this.user.image,
      status: this.user.status,
      login: this.user.login,
      password: this.user.password,
    });

    if (this.data.role === 'client') {
      this.getProd();
    }
  }

  getProd(): void {
    this.isLoading = true;
    this.service.getApplicationsClient(this.data.id).subscribe(
      products => {
        this.products = products;
        this.isLoading = false;
      },
      error => this.handleError('Erreur lors de la récupération des produits', error)
    );
  }

  getAllApplicationNotUser(): void {
    this.service.getAllApplicationsNotclient().subscribe(
      res => {
        this.appsWithoutUser = res;
        this.initForms();
        this.fetchUserData();
      },
      err => this.handleError('Erreur lors de la récupération des applications', err)
    );
  }

  get locals(): FormArray {
    return this.userForm.get('locals') as FormArray;
  }

  createLocal(): FormGroup {
    return this.fb.group({
      nom: ['', Validators.required],
      ville: ['', Validators.required],
      adresse: ['', Validators.required]
    });
  }

  addLocal(local?: any): void {
    this.locals.push(this.fb.group({
      id: [local ? local.id : null],
      nom: [local ? local.nom : '', Validators.required],
      ville: [local ? local.ville : '', Validators.required],
      adresse: [local ? local.adresse : '', Validators.required],
    }));
  }

  onAddLocal(): void {
    if (this.newLocalForm.valid) {
      const newLocal = { ...this.newLocalForm.value, id: this.user.id };
      this.isLoading = true;
      this.service.addLocal(newLocal).subscribe(
        res => {
          this.handleSuccess('Local ajouté avec succès', res, () => {
            this.locals.push(this.fb.group({
              id: [res.id],
              nom: [res.nom, Validators.required],
              ville: [res.ville, Validators.required],
              adresse: [res.adresse, Validators.required],
            }));
            this.newLocalForm.reset();
          });
        },
        error => this.handleError('Erreur lors de l\'ajout du local', error)
      );
    }
  }

  removeLocal(index: number, local: any): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const localId = local.get('id').value;
        if (localId) {
          this.isLoading = true;
          this.service.deleteLocal(localId).subscribe(
            res => {
              this.handleSuccess('Local supprimé avec succès', res, () => this.locals.removeAt(index));
            },
            error => this.handleError('Erreur lors de la suppression du local', error)
          );
        } else {
          this.locals.removeAt(index);
        }
      }
    });
  }

  removeProduit(index: number, prodId: number): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (prodId) {
          this.isLoading = true;
          this.service.removeApplication(prodId).subscribe(
            res => {
              this.handleSuccess('Produit supprimé avec succès', res, () => {
                this.products.splice(index, 1);
                this.cd.detectChanges();
              });
            },
            error => this.handleError('Erreur lors de la suppression du produit', error)
          );
        }
      }
    });
  }

  onSubmitLocal(local: any): void {
    if (local.valid) {
      const formData = new FormData();
      formData.append('id', local.value.id);
      formData.append('nom', local.value.nom);
      formData.append('ville', local.value.ville);
      formData.append('adresse', local.value.adresse);
      formData.append('client_id', this.data.id);

      this.service.updateLocal(formData).subscribe(
        res => {
          this.handleSuccess('Local mis à jour avec succès', res);
        },
        error => this.handleError('Erreur lors de la mise à jour du local', error)
      );
    } else {
      this.snackBar.open('Formulaire invalide', 'Fermer', { duration: 3000, panelClass: ['snackbar-error'] });
    }
  }

  onSubmit(): void {
    if (this.userForm.valid) {
      const utilisateurData = new FormData();
      utilisateurData.append('nom', this.userForm.get('nom')?.value);
      utilisateurData.append('prenom', this.userForm.get('prenom')?.value);
      utilisateurData.append('email', this.userForm.get('email')?.value);
      utilisateurData.append('telephone', this.userForm.get('telephone')?.value);
      utilisateurData.append('login', this.userForm.get('login')?.value);
      if (this.userForm.get('password')?.value) {
        utilisateurData.append('password', this.userForm.get('password')?.value);
      }
      this.service.getUserRole(this.data.role).subscribe(
        res => {
          if (this.data.role === 'client') {
            // Pour le client, pas de statut ni d'image
            this.service.updateClient(this.data.id, utilisateurData).subscribe(
              resClient => {
                this.handleSuccess('Client modifié avec succès', resClient);
                setTimeout(() => {
                  window.location.reload();
                }, 1500);
              },
              err => {
                this.handleError('Erreur lors de la modification du client', err);
              }
            );
          }
          else if (this.data.role === 'technicien') {
            // Ajouter le statut pour le technicien
            utilisateurData.append('status', this.userForm.get('status')?.value);

            // Ajouter l'image pour le technicien si elle est sélectionnée
            if (this.selectedFile) {
              utilisateurData.append('image', this.selectedFile);
            }

            // Debugging information
            console.log('Nom:', utilisateurData.get('nom'));
            console.log('Email:', utilisateurData.get('email'));
            console.log('Téléphone:', utilisateurData.get('telephone'));
            console.log('Login:', utilisateurData.get('login'));
            console.log('Status:', utilisateurData.get('status'));
            console.log('Image:', utilisateurData.get('image'));

            this.service.updateTechnicien(this.data.id, utilisateurData).subscribe(
              resClient => {
                this.handleSuccess('Technicien modifié avec succès', resClient);
                setTimeout(() => {
                  window.location.reload();
                }, 1500);
              },
              err => {
                this.handleError('Erreur lors de la modification du technicien', err);
              }
            );
          }
        },
        err => this.handleError('Erreur lors de la récupération du rôle de l\'utilisateur', err)
      );
    } else {
      this.snackBar.open('Formulaire invalide', 'Fermer', { duration: 3000, panelClass: ['snackbar-error'] });
    }
  }


  onCancel(): void {
    this.dialogRef.close();
    window.location.reload();
  }

  handleSuccess(message: string, data: any, callback?: () => void): void {
    this.isLoading = false;
    this.snackBar.open(message, 'Fermer', { duration: 3000, panelClass: ['snackbar-success'] });
    if (callback) callback();
  }

  handleError(message: string, error: any): void {
    this.isLoading = false;
    this.snackBar.open(message, 'Fermer', { duration: 3000, panelClass: ['snackbar-error'] });
  }

  getErrorMessage(formControlName: string): string {
    const control = this.userForm.get(formControlName);
    if (control?.hasError('required')) {
      return 'Ce champ est obligatoire';
    }
    if (control?.hasError('email')) {
      return 'Email invalide';
    }
    return '';
  }
}
