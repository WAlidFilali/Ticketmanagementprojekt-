import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import emailjs, { EmailJSResponseStatus } from 'emailjs-com';
import { TicketServiceService } from '../../../services/ticket-service.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  contactForm!: FormGroup;
  id_client!: any;
  info: any = {};

  constructor(private fb: FormBuilder,
              private service: TicketServiceService) {}

  ngOnInit(): void {
    this.contactForm = this.fb.group({
      nom: [this.info.nom, Validators.required],
      email: [this.info.email, [Validators.required, Validators.email]],
      recipients: ['', Validators.required],
      message: ['', Validators.required]
    });
    this.id_client = this.service.getIdUser();
    console.log('ID client pour récupérer email et nom: ' + this.id_client);
    this.getEmailEtNom();
  }

  getEmailEtNom(): void {
    this.service.getEmailNom(this.id_client).subscribe(
      (res: any) => {
        this.info = res;
        console.log("nom"+this.info.nom+"email"+this.info.email)
        this.contactForm.patchValue({
          nom: this.info.nom,
          email: this.info.email
        });
      },
      (error: any) => {
        console.log('Erreur: ' + error);
      }
    );
  }

  onSubmit(): void {
    if (this.contactForm.valid) {
      const recipients = this.contactForm.get('recipients')?.value;
      const recipientString = recipients.join(', ');

      const templateParams = {
        nom: this.contactForm.get('nom')?.value,
        email: this.contactForm.get('email')?.value,
        message: this.contactForm.get('message')?.value,
        recipients: recipientString
      };

      if (recipients.includes('walid.filali.2024@gmail.com')) {
        emailjs.send('service_4wxk67e', 'template_yifkesl', templateParams, 'Y5UVQAs5BSgQHmpKW')
          .then((result: EmailJSResponseStatus) => {
            window.location.reload();
            console.log('Email envoyé avec succès', result.text);
          }, (error) => {
            console.error('Erreur lors de l\'envoi de l\'email', error.text);
          });
      }

      if (recipients.includes('walid.filali@uit.ac.ma')) {
        emailjs.send('service_izlj7gi', 'template_15vfysp', templateParams, 'skxwyThSZUOa1eXKy')
          .then((result: EmailJSResponseStatus) => {
            window.location.reload();
            console.log('Email envoyé avec succès', result.text);
          }, (error) => {
            console.error('Erreur lors de l\'envoi de l\'email', error.text);
          });
      }
    }
  }
}
