import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import { TicketServiceService } from '../../../services/ticket-service.service';

@Component({
  selector: 'app-nouveautes',
  templateUrl: './nouveautes.component.html',
  styleUrls: ['./nouveautes.component.css']
})
export class NouveautesComponent implements OnInit {
  products: any[] = [];
  id: any;
  isLoading: boolean = false;
  totalDurationAnimation: number = 3;

  constructor(
    private ticketService: TicketServiceService,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {
    this.getNvProd();
  }

  getNvProd(): void {
    this.isLoading = true; // loading
    this.ticketService.getAllApplicationsThisYear().subscribe((products) => {
      this.products = products;
      }, error => {
      console.error(error);
      this.snackBar.open('Erreur lors de la récupération des nouveaux produits', 'Fermer', {
        duration: 3000,
        panelClass: ['snackbar-error']
      });
      this.isLoading = false;
    });
      this.isLoading = false;

  }

  base64ToBlob(base64: string, type: string): Blob {
    // Vérifiez que la chaîne Base64 est valide
    if (!base64 || base64.trim() === '') {
      throw new Error('Chaîne Base64 invalide');
    }

    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type });
  }

  getAnimationDelay(index: number): string {
    const delay = (index * this.totalDurationAnimation) / this.products.length;
    return `${delay}s`;
  }
}
