import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserNavTopComponent } from './user-nav-top.component';

describe('UserNavTopComponent', () => {
  let component: UserNavTopComponent;
  let fixture: ComponentFixture<UserNavTopComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UserNavTopComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UserNavTopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
