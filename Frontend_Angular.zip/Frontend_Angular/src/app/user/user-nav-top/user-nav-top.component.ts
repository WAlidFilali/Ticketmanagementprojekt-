import {Component, OnInit} from '@angular/core';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { TicketServiceService } from '../../services/ticket-service.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-user-nav-top',
  templateUrl: './user-nav-top.component.html',
  styleUrl: './user-nav-top.component.css',
})

export class UserNavTopComponent implements OnInit{
  isFirstVisit = true;
  isLogin = false;

  constructor(private service : TicketServiceService,
              private router : Router,
  ) {

  }

  ngOnInit() {
    console.log('id login');

  }

  getIdUser(){
    return this.service.getIdUser();
  }

  // login(){
  //   this.isLogin = !this.isLogin;
  //   const overlayDiv = document.querySelector('.link');

  //         console.log('iam gonna add login btn');
  //         if (overlayDiv) {
  //           overlayDiv.classList.add('add-login');
  //         }
  // }

  signOut(){
    this.service.setIdUser(0);
    this.router.navigateByUrl('/visit/login')

  }
}
