import { Component } from '@angular/core';
import { ProfilBtnService } from '../../profil-btn.service';
import { TicketServiceService } from '../../services/ticket-service.service';

@Component({
  selector: 'app-user-nav',
  templateUrl: './user-nav.component.html',
  styleUrl: './user-nav.component.css',
})
export class UserNavComponent {
  isLogin = false
  isActive = false;
  links = [
    { name: 'Demande Ticket', path: 'ticket/add' },
    { name: 'Mes Ticket', path: 'ticket/list/user'},
    { name: 'Mes Achats', path: 'achats' },
    // { name: 'Mes Contrats', path: '/mes-contrats' },
    // { name: 'Renover Contrat', path: '/renover-contrat' }
  ];

  constructor(private service : TicketServiceService){
    console.log('value btn : '+ service.getIdUser());

    if(this.service.getIdUser() != 0){
      this.isLogin = true
    }else{
      this.isLogin = false
    }
  }

  toggleNav(event: MouseEvent) {
    event.stopPropagation();
    this.isActive = !this.isActive;
    console.log(this.isActive ? "open" : "close");
    console.log('value : '+this.isActive);
  }
}
