import { Component, OnInit } from '@angular/core';
import { Ticket } from '../../Ticket.model';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Ticketservice } from '../../Ticketservice';

@Component({
  selector: 'app-user-ticket-list',
  templateUrl: './user-ticket-list.component.html',
  styleUrl: './user-ticket-list.component.css'
})
export class UserTicketListComponent implements OnInit{
  tickets: Ticket [] = [];
  id : any;
  isLoading: boolean = false;
  totalDurationAnimation: number = 3;

  constructor(private ticketService: Ticketservice,
              private route : ActivatedRoute,
              private snackBar : MatSnackBar){
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe(
      param =>{
        this.id = param.get('id');
        console.log(this.id);
        this.getTicket();
      }
    )

  }

  getTicket(): void {
    this.isLoading = true; // loading
    this.ticketService.getAllTicketUser(this.id).subscribe((tickets: Ticket[]) => {
      this.tickets = tickets;
      this.tickets.forEach(ticket => {
        console.log('Image URL:', 'http://localhost:8000/storage/' + ticket.image1);
      });
      this.isLoading = false;
    }, error => {
      console.error(error);
      this.snackBar.open('Erreur lors de recuperation des tickets', 'Fermer', {
        panelClass: ['snackbar-success']
      });
      this.isLoading = false;
    });
  }

  getAnimationDelay(index: number): string {
    const delay = (index * this.totalDurationAnimation) / this.tickets.length;
    return `${delay}s`;
  }
}
