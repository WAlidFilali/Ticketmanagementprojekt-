import { Component, OnInit } from '@angular/core';
import { Route } from '@angular/router';

@Component({
  selector: 'app-visitor-template',
  templateUrl: './visitor-template.component.html',
  styleUrl: './visitor-template.component.css'
})
export class VisitorTemplateComponent implements OnInit{
  constructor() {

  }

  ngOnInit(): void {

  }

}
