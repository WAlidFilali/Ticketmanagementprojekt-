import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoirHistoryInterventionActionComponent } from './voir-history-intervention-action.component';

describe('VoirHistoryInterventionActionComponent', () => {
  let component: VoirHistoryInterventionActionComponent;
  let fixture: ComponentFixture<VoirHistoryInterventionActionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VoirHistoryInterventionActionComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VoirHistoryInterventionActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
