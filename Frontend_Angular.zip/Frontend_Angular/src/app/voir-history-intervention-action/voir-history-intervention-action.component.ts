import { Component, ElementRef, Inject, OnInit, Renderer2 } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { TicketServiceService } from '../services/ticket-service.service';

@Component({
  selector: 'app-voir-history-intervention-action',
  templateUrl: './voir-history-intervention-action.component.html',
  styleUrl: './voir-history-intervention-action.component.css'
})
export class VoirHistoryInterventionActionComponent implements OnInit{
  isLoading: boolean = false;
  actions: any;
  produit:any
  id!: number;

  constructor(
    public dialogRef: MatDialogRef<VoirHistoryInterventionActionComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private ticketService: TicketServiceService,
    private sanitizer: DomSanitizer,
    private el: ElementRef,
    private renderer: Renderer2,
  ) {}

  ngOnInit(): void {
    // this.id = this.route.snapshot.params['id'];
    this.isLoading = true;
    this.getTicketActions(this.data);
    console.log('id actions -->'+this.data)
  }

  getProduit(id_app : number) {
    this.ticketService.getApplicationById(id_app).subscribe(
      (res : any)=>{
        this.produit = res
      },
      err=>{
        console.error();

      }
    )
  }

  getTicketActions(id: number): void {
    console.log('hana jit bch tchod detaionn-->'+id)
    this.ticketService.getActionsByIntervention(id).subscribe(
      data => {
        console.log("id h hwa-->"+data.id)
        this.actions = data;
        this.getProduit(this.actions.id_app);
        this.isLoading = false;
      },
      error => {
        console.error(error);
      }
    );
  }

  onCancel(): void {
    this.dialogRef.close();
    window.location.reload();
  }


  printHistory() {
    const printContents = document.getElementById('printable-section')!.innerHTML;
    const originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
    location.reload();
  }
}
