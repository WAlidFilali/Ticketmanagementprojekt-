import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoirlescompteComponent } from './voirlescompte.component';

describe('VoirlescompteComponent', () => {
  let component: VoirlescompteComponent;
  let fixture: ComponentFixture<VoirlescompteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VoirlescompteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VoirlescompteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
