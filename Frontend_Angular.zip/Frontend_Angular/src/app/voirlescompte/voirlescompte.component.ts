import { Overlay } from '@angular/cdk/overlay';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DomSanitizer } from '@angular/platform-browser';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { ErrorDialogComponent } from '../error-dialog/error-dialog.component';
import { ModifierapplicationComponent } from '../modifierapplication/modifierapplication.component';
import { TicketServiceService } from '../services/ticket-service.service';

@Component({
  selector: 'app-voirlescompte',
  templateUrl: './voirlescompte.component.html',
  styleUrl: './voirlescompte.component.css'
})
export class VoirlescompteComponent implements OnInit{
  accounts: any;
  id: any;
  isLoading: boolean = false;

  constructor(
    private service: TicketServiceService,
    private dialog: MatDialog,
    private overlay: Overlay,
    private snackBar : MatSnackBar,
  ) { }

  ngOnInit(): void {
    this.getAccount();
  }

  getAccount(): void {
    this.isLoading = true; // loading
    this.service.getAllComptes().subscribe(
      res => {
      this.accounts = res
      this.isLoading = false;
    }, error => {
      console.error(error);
      this.snackBar.open('Erreur lors de la récupération des comptes', 'Fermer', {
        duration: 3000,
        panelClass: ['snackbar-error']
      });
      this.isLoading = false;
    });
  }

  openEditAppDialog(user_id : number): void {
    const dialog = this.dialog.open(ModifierapplicationComponent , {
      width: '500px',
      data: user_id,
      scrollStrategy: this.overlay.scrollStrategies.block(),
    });

    dialog.afterClosed().subscribe(res=>{
      window.location.reload();
    })
  }

  deleteAccount(id: number): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.service.deleteCompte(id).subscribe({
          next: () => {
            this.openErrorDialog('Le compte a été supprimé',0);
            this.accounts = this.accounts.filter((acc: { id: number; }) => acc.id !== id);
          },
          error: (err: any) => {
            console.error(err);
          }
        });
      }
    });
  }

  openErrorDialog(message: string, additionalData: number): void {
    this.dialog.open(ErrorDialogComponent, {
      data: { message: message, additionalData: additionalData },
      width: '300px',
      disableClose: true
    });
  }

}

