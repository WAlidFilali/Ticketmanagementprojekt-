import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoirlisteapplicationComponent } from './voirlisteapplication.component';

describe('VoirlisteapplicationComponent', () => {
  let component: VoirlisteapplicationComponent;
  let fixture: ComponentFixture<VoirlisteapplicationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VoirlisteapplicationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VoirlisteapplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
