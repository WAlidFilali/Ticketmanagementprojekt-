import { Component } from '@angular/core';

@Component({
  selector: 'app-voirlisteapplication',
  templateUrl: './voirlisteapplication.component.html',
  styleUrl: './voirlisteapplication.component.css'
})
export class VoirlisteapplicationComponent {

}
