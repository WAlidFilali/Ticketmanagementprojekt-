import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoirlistetechnicianComponent } from './voirlistetechnician.component';

describe('VoirlistetechnicianComponent', () => {
  let component: VoirlistetechnicianComponent;
  let fixture: ComponentFixture<VoirlistetechnicianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VoirlistetechnicianComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VoirlistetechnicianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
