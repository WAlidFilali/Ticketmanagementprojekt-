import { Component } from '@angular/core';

@Component({
  selector: 'app-voirlistetechnician',
  templateUrl: './voirlistetechnician.component.html',
  styleUrl: './voirlistetechnician.component.css'
})
export class VoirlistetechnicianComponent {

}
