import { Overlay } from '@angular/cdk/overlay';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DomSanitizer } from '@angular/platform-browser';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { ErrorDialogComponent } from '../error-dialog/error-dialog.component';
import { ModifierapplicationComponent } from '../modifierapplication/modifierapplication.component';
import { TicketServiceService } from '../services/ticket-service.service';
import { TicketDetailsComponent } from '../ticket-details/ticket-details.component';
import { AffecterticketComponent } from '../affecterticket/affecterticket.component';
import {
  VoirHistoryInterventionActionComponent
} from "../voir-history-intervention-action/voir-history-intervention-action.component";

@Component({
  selector: 'app-voirticket',
  templateUrl: './voirticket.component.html',
  styleUrl: './voirticket.component.css'
})
export class VoirticketComponent implements OnInit {
  tickets: any[] = [];
  id_user: any;
  isLoading: boolean = false;

  constructor(
    private service: TicketServiceService,
    private dialog: MatDialog,
    private overlay: Overlay,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {
    this.id_user =  this.service.getIdUser();
    this.getTickets();
    console.log('techni id lmohim--->'+this.id_user)
  }

  getSanitizedImage(image: any) {
    return this.sanitizer.bypassSecurityTrustUrl(`data:image/png;base64,${image}`);
  }
  getStyles(etat: string): any {
    let color: string;

    switch (etat) {
      case 'EFFECTUER':
        color =  'var(--bay-of-many)';
        break;
      case 'ENCOURS':
        color =  'rgb(237, 179, 120)';
        break;
      case 'TERMINE':
        color = 'rgb(120, 237, 141)';
        break;
      case 'ABANDONER':
        color = 'rgb(141, 47, 218)';
        break;
      default:
        color =  'var(--amaranth)';
    }

    return {
      'border-color': color,
      'box-shadow': `0 0 15px ${color}`
    };

  }
  getEtatClass(etat: string): string {
    switch (etat) {
      case 'ENVOYER':
        return 'etat-envoye';
      case 'EFFECTUER':
        return 'etat-effectue';
      case 'EN COURS':
        return 'etat-en-cours';
      case 'TERMINE':
        return 'etat-termine';
      case 'ABANDONER':
        return 'etat-abandone';
      default:
        return '';
    }
  }

  getTickets(): void {
    this.isLoading = true; // loading
    this.service.getTicketEnvoye().subscribe((tickets) => {
      this.tickets = tickets;
      this.isLoading = false;
    }, error => {
      console.error(error);
      this.snackBar.open('Erreur lors de la récupération des Tickets', 'Fermer', {
        duration: 3000,
        panelClass: ['snackbar-error']
      });
      this.isLoading = false;
    });
  }

  openDetailTicketDialog(ticket_id: number): void {
    const dialog = this.dialog.open(TicketDetailsComponent , {
      width: '450px',
      data: ticket_id,
      scrollStrategy: this.overlay.scrollStrategies.block(),
    });

    dialog.afterClosed().subscribe(res=>{
      window.location.reload();
    })
  }

  annulerTicket(id: number): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.service.removeTicket(id).subscribe({
          next: () => {
            this.openErrorDialog('Ticket a été annulé', 0);
            this.tickets = this.tickets.filter(ticket => ticket.id !== id);
          },
          error: (err: any) => {
            console.error(err);
          }
        });
      }
    });
  }

  openAffecterTicketDialog(id : number){
    const dialog = this.dialog.open(AffecterticketComponent , {
      data: id,
      scrollStrategy: this.overlay.scrollStrategies.block(),
    });

    dialog.afterClosed().subscribe(res=>{
      window.location.reload();
    })
  }

  openErrorDialog(message: string, additionalData: number): void {
    this.dialog.open(ErrorDialogComponent, {
      data: { message: message, additionalData: additionalData },
      width: '300px',
      disableClose: true
    });
  }

  openHistoryInterventionDialog(id : number){
    const dialog = this.dialog.open(VoirHistoryInterventionActionComponent , {
      width: '600px',
      data: id,
      scrollStrategy: this.overlay.scrollStrategies.block(),
    });

    dialog.afterClosed().subscribe(res=>{
      window.location.reload();
    })
  }
}
